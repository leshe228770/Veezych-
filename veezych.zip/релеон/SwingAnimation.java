/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1306
 *  net.minecraft.class_1764
 *  net.minecraft.class_1799
 *  net.minecraft.class_1835
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 *  net.minecraft.class_7923
 *  org.joml.Quaternionfc
 */
package releon.ru.api.module.impl.visual;

import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import org.joml.Quaternionfc;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.HandAnimationEvent;
import releon.ru.api.events.impl.SwingDurationEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;

public class SwingAnimation
extends Module {
    private final ModeSetting swingType = this.register(new ModeSetting("Type", "Swing animation type.", "Chop", "Chop", "Swipe", "Down", "Smooth", "Smooth 2", "Power", "Feast", "Twist", "Stab", "Helix", "Default"));
    private final NumberSetting hitStrength = this.register(new NumberSetting("Strength", "Swing animation strength.", 1.0, 0.5, 3.0, 0.05));
    private final NumberSetting swingSpeed = this.register(new NumberSetting("Duration", "Swing animation duration multiplier.", 1.0, 0.5, 4.0, 0.05));
    private final BooleanSetting onlySwing = this.register(new BooleanSetting("Only Swing", "Animate only while the player swings.", false));
    private final BooleanSetting onlyAura = this.register(new BooleanSetting("Only Aura", "Animate only while Aura has a target.", false));

    public SwingAnimation() {
        super("Swing Animation", "Custom first-person swing animations.", ModuleCategory.VISUAL);
    }

    @SubscribeEvent
    private void onSwingDuration(SwingDurationEvent event) {
        if (this.isBlockedForSwingAnimation(class_1268.field_5808) || this.isBlockedForSwingAnimation(class_1268.field_5810)) {
            return;
        }
        if (this.passesAuraFilter()) {
            event.setAnimation(this.swingSpeed.getFloat());
            event.cancel();
        }
    }

    @SubscribeEvent
    private void onHandAnimation(HandAnimationEvent event) {
        if (SwingAnimation.mc.field_1724 == null || event.getHand() != class_1268.field_5808 || this.isBlockedForSwingAnimation(event.getHand()) || !this.passesAuraFilter()) {
            return;
        }
        class_4587 matrices = event.getMatrices();
        float swingProgress = event.getSwingProgress();
        int armSide = SwingAnimation.mc.field_1724.method_6068() == class_1306.field_6183 ? 1 : -1;
        float sin1 = class_3532.method_15374((double)(swingProgress * swingProgress * (float)Math.PI));
        float sin2 = class_3532.method_15374((double)(class_3532.method_15355((float)swingProgress) * (float)Math.PI));
        float sinSmooth = (float)(Math.sin((double)swingProgress * Math.PI) * 0.5);
        float strength = this.hitStrength.getFloat();
        if (((Boolean)this.onlySwing.getValue()).booleanValue() && SwingAnimation.mc.field_1724.field_6279 == 0) {
            matrices.method_46416((float)armSide * 0.56f, -0.52f, -0.72f);
        } else if (this.swingType.is("Chop")) {
            matrices.method_46416(0.56f * (float)armSide, -0.44f, -0.72f);
            matrices.method_46416(0.0f, -0.19800001f, 0.0f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(45.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(sin2 * -20.0f * (float)armSide * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -80.0f * strength));
            matrices.method_46416(0.4f, 0.2f, 0.2f);
            matrices.method_46416(-0.5f, 0.08f, 0.0f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(20.0f));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-80.0f));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(20.0f));
        } else if (this.swingType.is("Twist")) {
            matrices.method_46416((float)armSide * 0.56f, -0.36f, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(80.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -90.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((sin1 - sin2) * 60.0f * (float)armSide * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-30.0f));
            matrices.method_46416(0.0f, -0.1f, 0.05f);
        } else if (this.swingType.is("Swipe")) {
            matrices.method_46416(0.56f * (float)armSide, -0.32f, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(70.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(-20.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(sin2 * sin1 * -5.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * sin1 * -120.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-70.0f));
        } else if (this.swingType.is("Default")) {
            matrices.method_46416((float)armSide * 0.56f, -0.52f - sin2 * 0.5f * strength, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(45.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(-45.0f * (float)armSide));
        } else if (this.swingType.is("Down")) {
            matrices.method_46416((float)armSide * 0.56f, -0.32f, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(76.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(sin2 * -5.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40713.rotationDegrees(sin2 * -100.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -155.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-100.0f));
        } else if (this.swingType.is("Smooth")) {
            matrices.method_46416((float)armSide * 0.56f, -0.42f, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)armSide * (45.0f + sin1 * -20.0f * strength)));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)armSide * sin2 * -20.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -80.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)armSide * -45.0f));
            matrices.method_46416(0.0f, -0.1f, 0.0f);
        } else if (this.swingType.is("Smooth 2")) {
            matrices.method_46416((float)armSide * 0.56f, -0.42f, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -80.0f * strength));
            matrices.method_46416(0.0f, -0.1f, 0.0f);
        } else if (this.swingType.is("Power")) {
            matrices.method_46416((float)armSide * 0.56f, -0.32f, -0.72f);
            matrices.method_46416(-sinSmooth * sinSmooth * sin1 * (float)armSide * strength, 0.0f, 0.0f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(61.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(sin2 * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(sin2 * sin1 * -5.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * sin1 * -30.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-60.0f));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sinSmooth * -60.0f * strength));
        } else if (this.swingType.is("Feast")) {
            matrices.method_46416((float)armSide * 0.56f, -0.32f, -0.72f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(30.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(sin2 * 75.0f * (float)armSide * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -45.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(30.0f * (float)armSide));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-80.0f));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(35.0f * (float)armSide));
        } else if (this.swingType.is("Stab")) {
            matrices.method_46416((float)armSide * 0.66f, -0.32f, -0.92f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)(25 * armSide)));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(sin2 * 90.0f * (float)armSide * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -15.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)(50 * armSide)));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-90.0f));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)(70 * armSide)));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)(2 * armSide)));
        } else if (this.swingType.is("Helix")) {
            matrices.method_46416((float)armSide * 0.66f, -0.32f, -0.92f);
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)(35 * armSide)));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(sin2 * 15.0f * (float)armSide * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(sin2 * -55.0f * strength));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)(50 * armSide)));
            matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-90.0f));
            matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)(70 * armSide)));
            matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)(2 * armSide)));
        }
        event.cancel();
    }

    private boolean passesAuraFilter() {
        AuraModule aura = AuraModule.getInstance();
        return (Boolean)this.onlyAura.getValue() == false || aura != null && aura.isEnabled() && AuraModule.target != null;
    }

    private boolean isBlockedForSwingAnimation(class_1268 hand) {
        return SwingAnimation.mc.field_1724 != null && this.isExcludedSwingItem(SwingAnimation.mc.field_1724.method_5998(hand));
    }

    private boolean isExcludedSwingItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (stack.method_7909() instanceof class_1764 || stack.method_7909() instanceof class_1835) {
            return true;
        }
        String path = class_7923.field_41178.method_10221((Object)stack.method_7909()).method_12832();
        return path.contains("spear");
    }
}

