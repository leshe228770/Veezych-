/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.class_1297
 *  net.minecraft.class_1297$class_5529
 *  net.minecraft.class_243
 *  net.minecraft.class_2678
 *  net.minecraft.class_2724
 *  net.minecraft.class_2828
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_5498
 *  net.minecraft.class_745
 */
package releon.ru.api.module.impl.player;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_745;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.CameraPositionEvent;
import releon.ru.api.events.impl.ChunkOcclusionEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.move.MoveUtil;

public final class FreeCam
extends Module {
    private static final int FAKE_PLAYER_ENTITY_ID = -81374659;
    private static FreeCam instance;
    private final NumberSetting speedSetting = this.register(new NumberSetting("Speed", "Free camera speed.", 2.0, 0.5, 5.0, 0.1));
    private final BooleanSetting freezeSetting = this.register(new BooleanSetting("Freeze", "Freeze player on place.", false));
    public class_243 pos;
    public class_243 prevPos;
    private class_745 fakePlayerEntity;

    public FreeCam() {
        super("Free Cam", "Detached free camera.", ModuleCategory.PLAYER);
        instance = this;
    }

    public static FreeCam getInstance() {
        return instance;
    }

    @Override
    protected void onEnable() {
        class_310 client = class_310.method_1551();
        class_243 cameraPos = client.field_1773 != null && client.field_1773.method_19418() != null ? client.field_1773.method_19418().method_71156() : (client.field_1724 != null ? client.field_1724.method_33571() : class_243.field_1353);
        this.pos = this.isFinite(cameraPos) ? cameraPos : class_243.field_1353;
        this.prevPos = this.pos;
        this.spawnFakePlayerEntity(client);
    }

    @Override
    protected void onDisable() {
        this.resetRuntimeState();
        this.removeFakePlayerEntity(class_310.method_1551());
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (event.getPacket() instanceof class_2828 && ((Boolean)this.freezeSetting.getValue()).booleanValue()) {
            event.setCancelled(true);
        } else if (event.getPacket() instanceof class_2724 || event.getPacket() instanceof class_2678) {
            this.setEnabled(false);
        }
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        if (this.pos == null) {
            return;
        }
        float speed = this.speedSetting.getFloat();
        double[] motion = MoveUtil.calculateDirection(event.forward(), event.sideways(), speed);
        this.prevPos = this.pos;
        this.pos = this.pos.method_1031(motion[0], event.getInput().comp_3163() ? (double)speed : (event.getInput().comp_3164() ? (double)(-speed) : 0.0), motion[1]);
        event.inputNone();
    }

    @SubscribeEvent
    private void onCameraPosition(CameraPositionEvent event) {
        class_310 client = class_310.method_1551();
        if (!this.isFinite(this.prevPos) || !this.isFinite(this.pos)) {
            class_243 fallback;
            this.prevPos = fallback = this.isFinite(event.getPos()) ? event.getPos() : (client.field_1724 != null ? client.field_1724.method_33571() : class_243.field_1353);
            this.pos = fallback;
        }
        if (this.isFinite(this.pos)) {
            float tickDelta = client.method_61966() != null ? class_3532.method_15363((float)client.method_61966().method_60637(false), (float)0.0f, (float)1.0f) : 1.0f;
            event.setPos(this.prevPos.method_35590(this.pos, (double)tickDelta));
        }
        if (client.field_1690 != null) {
            client.field_1690.method_31043(class_5498.field_26664);
        }
    }

    @SubscribeEvent
    private void onChunkOcclusion(ChunkOcclusionEvent event) {
        event.setCancelled(true);
    }

    public boolean hasDetachedCameraState() {
        return this.isFinite(this.pos) || this.isFinite(this.prevPos) || this.fakePlayerEntity != null;
    }

    public void resetRuntimeState() {
        this.pos = null;
        this.prevPos = null;
    }

    private void spawnFakePlayerEntity(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        this.removeFakePlayerEntity(client);
        GameProfile profile = new GameProfile(UUID.randomUUID(), this.resolveProfileName(client.field_1724.method_7334()));
        class_745 fake = new class_745(client.field_1687, profile);
        fake.method_5838(-81374659);
        fake.method_5719((class_1297)client.field_1724);
        fake.method_36456(client.field_1724.method_36454());
        fake.method_36457(client.field_1724.method_36455());
        fake.method_5847(client.field_1724.method_5791());
        fake.method_5728(client.field_1724.method_5624());
        fake.method_5660(client.field_1724.method_5715());
        fake.method_18380(client.field_1724.method_18376());
        fake.method_6033(client.field_1724.method_6032());
        fake.method_6073(client.field_1724.method_6067());
        for (int i = 0; i < client.field_1724.method_31548().method_5439(); ++i) {
            fake.method_31548().method_5447(i, client.field_1724.method_31548().method_5438(i).method_7972());
        }
        fake.method_31548().method_61496(client.field_1724.method_31548().method_67532());
        client.field_1687.method_53875((class_1297)fake);
        this.fakePlayerEntity = fake;
    }

    private void removeFakePlayerEntity(class_310 client) {
        if (client.field_1687 != null) {
            client.field_1687.method_2945(-81374659, class_1297.class_5529.field_26999);
            if (this.fakePlayerEntity != null && this.fakePlayerEntity.method_5628() != -81374659) {
                client.field_1687.method_2945(this.fakePlayerEntity.method_5628(), class_1297.class_5529.field_26999);
            }
        }
        if (this.fakePlayerEntity != null) {
            this.fakePlayerEntity.method_31472();
        }
        this.fakePlayerEntity = null;
    }

    private boolean isFinite(class_243 vec) {
        return vec != null && Double.isFinite(vec.field_1352) && Double.isFinite(vec.field_1351) && Double.isFinite(vec.field_1350);
    }

    private String resolveProfileName(GameProfile profile) {
        String name;
        Object value = this.invokeProfileMethod(profile, "name");
        if (!(value instanceof String)) {
            value = this.invokeProfileMethod(profile, "getName");
        }
        return value instanceof String ? (name = (String)value) : "FreeCam";
    }

    private Object invokeProfileMethod(GameProfile profile, String methodName) {
        try {
            return GameProfile.class.getMethod(methodName, new Class[0]).invoke((Object)profile, new Object[0]);
        }
        catch (ReflectiveOperationException ignored) {
            return null;
        }
    }
}

