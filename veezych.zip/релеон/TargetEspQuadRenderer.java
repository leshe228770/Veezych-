/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_12249
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_4588
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_7833
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 */
package releon.ru.utils.render.world.targetesp;

import net.minecraft.class_12249;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import releon.ru.utils.render.WorldVertex;

final class TargetEspQuadRenderer {
    private TargetEspQuadRenderer() {
    }

    static void billboard(class_4587 stack, class_4597.class_4598 provider, class_2960 texture, float y, float scale, float rotation, int c1, int c2, int c3, int c4) {
        class_4588 consumer = provider.method_73477(class_12249.method_76000((class_2960)texture));
        Quaternionf cameraRotation = class_310.method_1551().field_1773.method_19418().method_23767();
        stack.method_22903();
        stack.method_46416(0.0f, y, 0.0f);
        stack.method_22907((Quaternionfc)cameraRotation);
        if (rotation != 0.0f) {
            stack.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(rotation));
        }
        stack.method_22905(scale, scale, 1.0f);
        class_4587.class_4665 pose = stack.method_23760();
        WorldVertex.textured(consumer, pose, -1.0f, -1.0f, 0.0f, 0.0f, 0.0f, c1);
        WorldVertex.textured(consumer, pose, -1.0f, 1.0f, 0.0f, 0.0f, 1.0f, c2);
        WorldVertex.textured(consumer, pose, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, c3);
        WorldVertex.textured(consumer, pose, 1.0f, -1.0f, 0.0f, 1.0f, 0.0f, c4);
        stack.method_22909();
    }

    static void end(class_4597.class_4598 provider, class_2960 texture) {
        provider.method_22994(class_12249.method_76000((class_2960)texture));
    }
}

