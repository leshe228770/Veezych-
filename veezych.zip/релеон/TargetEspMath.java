/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3532
 */
package releon.ru.utils.render.world.targetesp;

import net.minecraft.class_3532;

public final class TargetEspMath {
    private TargetEspMath() {
    }

    public static float approach(float current, float target, float delta) {
        if (current < target) {
            return Math.min(current + delta, target);
        }
        return Math.max(current - delta, target);
    }

    public static float easeOutCubic(float value) {
        float clamped = class_3532.method_15363((float)value, (float)0.0f, (float)1.0f);
        float inv = 1.0f - clamped;
        return 1.0f - inv * inv * inv;
    }
}

