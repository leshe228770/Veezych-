/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_4588
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_7833
 *  org.joml.Quaternionfc
 */
package releon.ru.utils.render.world.targetesp;

import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.pipeline.ClientPipelines;
import releon.ru.utils.render.world.targetesp.TargetEspRenderContext;

public final class GhostTargetEspRenderer {
    private static final class_2960 GHOST_TEXTURE = class_2960.method_60655((String)"releon", (String)"textures/particles/ghost-glow.png");

    private GhostTargetEspRenderer() {
    }

    public static void render(class_4587 stack, class_4597.class_4598 provider, TargetEspRenderContext context) {
        class_4588 consumer = provider.method_73477(ClientPipelines.GHOSTS_ESP.apply(GHOST_TEXTURE));
        stack.method_22903();
        stack.method_46416(0.0f, context.target().method_17682() * 0.6f, 0.0f);
        GhostTargetEspRenderer.particle(stack, consumer, context, TransformationType.FIRST);
        GhostTargetEspRenderer.particle(stack, consumer, context, TransformationType.SECOND);
        GhostTargetEspRenderer.particle(stack, consumer, context, TransformationType.THIRD);
        stack.method_22909();
    }

    private static void particle(class_4587 stack, class_4588 consumer, TargetEspRenderContext context, TransformationType transformation) {
        double radius = 0.8f;
        double distance = 20.0;
        float particleSize = 1.0f;
        int alphaFactor = 1;
        int particleCount = Math.max(4, Math.round(10.0f * context.alpha()));
        for (int i = 0; i < particleCount; ++i) {
            stack.method_22903();
            double angle = 0.2 * ((double)context.frameTimeMs() * 0.55 - (double)i * distance) / 40.0;
            double sin = Math.sin(angle) * radius;
            double cos = Math.cos(angle) * radius;
            class_243 trans = transformation.make(sin, cos);
            stack.method_22904(trans.field_1352, trans.field_1351, trans.field_1350);
            stack.method_22907((Quaternionfc)class_310.method_1551().field_1773.method_19418().method_23767());
            float spinRotation = (float)context.frameTimeMs() * 0.1f - (float)i * 10.0f;
            stack.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(spinRotation));
            stack.method_46416(particleSize / 2.0f, particleSize / 2.0f, 0.0f);
            int currentAlpha = (int)((float)(255 - i * alphaFactor) * context.alpha());
            int startColor = ColorUtil.withAlpha(context.primaryColor(), currentAlpha);
            int endColor = ColorUtil.withAlpha(context.secondaryColor(), currentAlpha);
            class_4587.class_4665 entry = stack.method_23760();
            consumer.method_56824(entry, 0.0f, -particleSize, 0.0f).method_22913(0.0f, 0.0f).method_39415(endColor);
            consumer.method_56824(entry, -particleSize, -particleSize, 0.0f).method_22913(0.0f, 1.0f).method_39415(endColor);
            consumer.method_56824(entry, -particleSize, 0.0f, 0.0f).method_22913(1.0f, 1.0f).method_39415(startColor);
            consumer.method_56824(entry, 0.0f, 0.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(startColor);
            stack.method_22909();
        }
    }

    public static void endBatch(class_4597.class_4598 provider) {
        provider.method_22994(ClientPipelines.GHOSTS_ESP.apply(GHOST_TEXTURE));
    }

    private static enum TransformationType {
        FIRST{

            @Override
            class_243 make(double sin, double cos) {
                return new class_243(sin, cos, -cos);
            }
        }
        ,
        SECOND{

            @Override
            class_243 make(double sin, double cos) {
                return new class_243(-sin, sin, -cos);
            }
        }
        ,
        THIRD{

            @Override
            class_243 make(double sin, double cos) {
                return new class_243(-sin, -sin, cos);
            }
        };


        abstract class_243 make(double var1, double var3);
    }
}

