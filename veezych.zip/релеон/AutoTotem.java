/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_304
 *  net.minecraft.class_310
 *  net.minecraft.class_3675
 */
package releon.ru.api.module.impl.combat;

import java.util.Locale;
import java.util.function.Predicate;
import net.minecraft.class_1041;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.InventoryTask;

public class AutoTotem
extends Module {
    private static final long EQUIP_ATTEMPT_COOLDOWN_MS = 250L;
    private static final long SLOWING_DOWN_DELAY_MS = 1L;
    private static final long SWAP_DELAY_MS = 25L;
    private static final long AWAIT_SWITCH_TIMEOUT_MS = 50L;
    private static final long RESTORE_SLOT_DELAY_MS = 25L;
    private static final long SPEEDING_UP_DELAY_MS = 25L;
    private final NumberSetting healthThreshold = this.register(new NumberSetting("Health", "Health threshold.", 4.5, 1.0, 20.0, 0.5));
    private final NumberSetting elytraHealth = this.register(new NumberSetting("Elytra Health", "Elytra health threshold.", 8.5, 1.0, 20.0, 0.5));
    private final MultiModeSetting triggers = this.register(new MultiModeSetting("Triggers", "Totem equip triggers.", new String[]{"Crystal", "Fall", "Elytra"}, "Crystal", "Fall", "Elytra"));
    private final BooleanSetting returnItem = this.register(new BooleanSetting("Return Item", "Return offhand item after danger.", true));
    private final NumberSetting crystalDistance = this.register(new NumberSetting("Crystal Distance", "Danger crystal distance.", 4.0, 1.0, 6.0, 0.5));
    private final NumberSetting crystalHeight = this.register(new NumberSetting("Crystal Height", "Danger crystal vertical distance.", 2.5, 0.5, 8.0, 0.5));
    private final NumberSetting fallHeight = this.register(new NumberSetting("Fall Height", "Danger fall height.", 15.0, 5.0, 50.0, 1.0));
    private int savedSlot = -1;
    private int totemSlot = -1;
    private int previousOffhandSourceSlot = -1;
    private float fallStartY;
    private boolean wasFalling;
    private boolean keysOverridden;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private boolean wasSprintPressed;
    private class_1799 previousOffhandStack = class_1799.field_8037;
    private boolean needsReturn;
    private long actionStartTime;
    private long lastEquipAttemptMs;
    private Phase phase = Phase.READY;

    public AutoTotem() {
        super("Auto Totem", "Automatically equips totems.", ModuleCategory.COMBAT);
        this.crystalDistance.visibleWhen(() -> this.triggers.isSelected("Crystal"));
        this.crystalHeight.visibleWhen(() -> this.triggers.isSelected("Crystal"));
        this.fallHeight.visibleWhen(() -> this.triggers.isSelected("Fall"));
        this.elytraHealth.visibleWhen(() -> this.triggers.isSelected("Elytra"));
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null || client.field_1687 == null) {
            this.resetState();
            this.clearReturnState();
            return;
        }
        this.updateFallTracking(client);
        if (this.phase != Phase.READY) {
            this.execute(client);
            return;
        }
        boolean shouldEquip = this.shouldEquipTotem(client);
        if (shouldEquip) {
            long now = System.currentTimeMillis();
            if (now - this.lastEquipAttemptMs >= 250L) {
                this.tryEquipTotem(client);
            }
            return;
        }
        if (this.needsReturn && ((Boolean)this.returnItem.getValue()).booleanValue() && !this.previousOffhandStack.method_7960()) {
            if (this.isTotemInOffhand(client)) {
                this.startLegitReturn(client);
            } else {
                this.clearReturnState();
            }
        }
    }

    @Override
    protected void onDisable() {
        this.resetState();
        this.clearReturnState();
    }

    private void tryEquipTotem(class_310 client) {
        if (this.phase != Phase.READY || client.field_1755 != null || this.isPreferredTotemAlreadyInOffhand(client)) {
            return;
        }
        this.lastEquipAttemptMs = System.currentTimeMillis();
        class_1735 slot = this.findPreferredTotemSlot(client);
        if (slot == null) {
            return;
        }
        int slotId = this.getMenuSlotId(client, slot);
        if (slotId == -1) {
            return;
        }
        this.savedSlot = client.field_1724.method_31548().method_67532();
        this.totemSlot = slotId;
        this.previousOffhandStack = client.field_1724.method_6079().method_7972();
        this.previousOffhandSourceSlot = slotId;
        this.needsReturn = !this.previousOffhandStack.method_7960();
        this.startLegitEquip(client);
    }

    private void startLegitEquip(class_310 client) {
        this.captureKeyStates(client);
        this.phase = Phase.SLOWING_DOWN;
        this.actionStartTime = System.currentTimeMillis();
        this.keysOverridden = false;
    }

    private void startLegitReturn(class_310 client) {
        this.captureKeyStates(client);
        this.phase = Phase.RETURN_SLOWING_DOWN;
        this.actionStartTime = System.currentTimeMillis();
        this.keysOverridden = false;
    }

    private void execute(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null || client.field_1755 != null) {
            this.resetState();
            return;
        }
        long elapsed = System.currentTimeMillis() - this.actionStartTime;
        switch (this.phase.ordinal()) {
            case 1: {
                this.stopPlayerInput(client);
                if (elapsed <= 1L) break;
                this.phase = Phase.SWAP_TOTEM;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 2: {
                this.stopPlayerInput(client);
                if (elapsed <= 25L) {
                    return;
                }
                if (this.totemSlot == -1 || !this.clickOffhandSwap(client, this.totemSlot)) {
                    this.resetState();
                    return;
                }
                this.phase = Phase.AWAIT_SWITCH;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 3: {
                this.stopPlayerInput(client);
                if (!this.isTotemInOffhand(client) && elapsed <= 50L) break;
                this.phase = Phase.RESTORE_SLOT;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 4: {
                this.stopPlayerInput(client);
                if (elapsed <= 25L) {
                    return;
                }
                if (this.savedSlot >= 0 && this.savedSlot <= 8) {
                    InventoryTask.switchTo(this.savedSlot);
                }
                this.phase = Phase.SPEEDING_UP;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 5: {
                this.stopPlayerInput(client);
                if (elapsed <= 1L) break;
                this.phase = Phase.RETURN_ITEM;
                this.actionStartTime = System.currentTimeMillis();
                break;
            }
            case 6: {
                this.stopPlayerInput(client);
                if (elapsed <= 25L) {
                    return;
                }
                if (this.attemptReturnPreviousItem(client)) {
                    this.clearReturnState();
                    this.phase = Phase.SPEEDING_UP;
                    this.actionStartTime = System.currentTimeMillis();
                    break;
                }
                this.resetState();
                this.clearReturnState();
                break;
            }
            case 7: {
                if (elapsed < 25L) break;
                this.restoreKeyStates(client);
                this.resetState();
                break;
            }
        }
    }

    private void updateFallTracking(class_310 client) {
        boolean falling;
        boolean bl = falling = client.field_1724.method_18798().field_1351 < -0.1 && !client.field_1724.method_24828() && !client.field_1724.method_6101() && !client.field_1724.method_5799();
        if (falling && !this.wasFalling) {
            this.fallStartY = (float)client.field_1724.method_23318();
        }
        if (client.field_1724.method_24828() || client.field_1724.method_5799() || client.field_1724.method_6101()) {
            this.fallStartY = (float)client.field_1724.method_23318();
        }
        this.wasFalling = falling;
    }

    private boolean shouldEquipTotem(class_310 client) {
        if (client.field_1724.method_6032() <= this.healthThreshold.getFloat()) {
            return true;
        }
        if (this.triggers.isSelected("Elytra") && client.field_1724.method_6128() && client.field_1724.method_6032() <= this.elytraHealth.getFloat()) {
            return true;
        }
        if (this.triggers.isSelected("Fall") && this.fallStartY - (float)client.field_1724.method_23318() >= this.fallHeight.getFloat() && client.field_1724.method_18798().field_1351 < -0.1) {
            return true;
        }
        return this.triggers.isSelected("Crystal") && this.checkCrystalDanger(client);
    }

    private boolean checkCrystalDanger(class_310 client) {
        double maxHorizontal = (Double)this.crystalDistance.getValue();
        double maxVertical = (Double)this.crystalHeight.getValue();
        for (class_1297 entity : client.field_1687.method_18112()) {
            double horizontal;
            double vertical;
            if (!(entity instanceof class_1511) || (vertical = Math.abs(entity.method_23318() - client.field_1724.method_23318())) > maxVertical || !((horizontal = Math.hypot(entity.method_23317() - client.field_1724.method_23317(), entity.method_23321() - client.field_1724.method_23321())) <= maxHorizontal)) continue;
            return true;
        }
        return false;
    }

    private class_1735 findPreferredTotemSlot(class_310 client) {
        class_1735 plain = this.findSlot(client, this::isPlainTotem);
        if (plain != null) {
            return plain;
        }
        class_1735 nonSphere = this.findSlot(client, this::isTotemButNotSphere);
        if (nonSphere != null) {
            return nonSphere;
        }
        return this.findSlot(client, stack -> stack.method_7909() == class_1802.field_8288);
    }

    private class_1735 findSlot(class_310 client, Predicate<class_1799> predicate) {
        for (int i = 0; i < client.field_1724.field_7498.field_7761.size(); ++i) {
            class_1799 stack;
            class_1735 slot = client.field_1724.field_7498.method_7611(i);
            if (!this.isValidInventorySlot(client, i, slot) || (stack = slot.method_7677()).method_7960() || !predicate.test(stack)) continue;
            return slot;
        }
        return null;
    }

    private boolean isValidInventorySlot(class_310 client, int slotId, class_1735 slot) {
        return slot != null && slot.field_7871 == client.field_1724.method_31548() && slotId != 45 && slotId != 46;
    }

    private boolean isPlainTotem(class_1799 stack) {
        return this.isTotemButNotSphere(stack) && !stack.method_7942();
    }

    private boolean isTotemButNotSphere(class_1799 stack) {
        return stack.method_7909() == class_1802.field_8288 && !this.isSphereTotem(stack);
    }

    private boolean isSphereTotem(class_1799 stack) {
        if (stack.method_7909() != class_1802.field_8288) {
            return false;
        }
        String name = stack.method_7964().getString().toLowerCase(Locale.ROOT);
        return name.contains("sphere");
    }

    private boolean isTotemInOffhand(class_310 client) {
        return client.field_1724.method_6079().method_7909() == class_1802.field_8288;
    }

    private boolean isPreferredTotemAlreadyInOffhand(class_310 client) {
        if (!this.isTotemInOffhand(client)) {
            return false;
        }
        class_1799 offhand = client.field_1724.method_6079();
        return this.isPlainTotem(offhand) || this.findSlot(client, this::isPlainTotem) == null;
    }

    private boolean attemptReturnPreviousItem(class_310 client) {
        class_1735 restoreSlot;
        if (!((Boolean)this.returnItem.getValue()).booleanValue() || this.previousOffhandStack.method_7960() || !this.isTotemInOffhand(client)) {
            return false;
        }
        if (this.isValidMenuSlot(client, this.previousOffhandSourceSlot) && this.stackMatchesForReturn((restoreSlot = client.field_1724.field_7498.method_7611(this.previousOffhandSourceSlot)).method_7677())) {
            return this.clickOffhandSwap(client, this.previousOffhandSourceSlot);
        }
        class_1735 exactSlot = this.findSlot(client, this::stackMatchesForReturn);
        if (exactSlot != null) {
            return this.clickOffhandSwap(client, this.getMenuSlotId(client, exactSlot));
        }
        class_1735 sameItemSlot = this.findSlot(client, stack -> !stack.method_7960() && stack.method_7909() == this.previousOffhandStack.method_7909());
        return sameItemSlot != null && this.clickOffhandSwap(client, this.getMenuSlotId(client, sameItemSlot));
    }

    private boolean stackMatchesForReturn(class_1799 stack) {
        if (stack == null || stack.method_7960() || this.previousOffhandStack.method_7960()) {
            return false;
        }
        return stack.method_7909() == this.previousOffhandStack.method_7909() && stack.method_7942() == this.previousOffhandStack.method_7942() && stack.method_7964().getString().equals(this.previousOffhandStack.method_7964().getString());
    }

    private boolean clickOffhandSwap(class_310 client, int slotId) {
        if (!this.isValidMenuSlot(client, slotId)) {
            return false;
        }
        client.field_1761.method_2906(client.field_1724.field_7498.field_7763, slotId, 40, class_1713.field_7791, (class_1657)client.field_1724);
        return true;
    }

    private boolean isValidMenuSlot(class_310 client, int slotId) {
        return slotId >= 0 && slotId < client.field_1724.field_7498.field_7761.size();
    }

    private int getMenuSlotId(class_310 client, class_1735 slot) {
        if (slot == null) {
            return -1;
        }
        for (int i = 0; i < client.field_1724.field_7498.field_7761.size(); ++i) {
            if (client.field_1724.field_7498.method_7611(i) != slot) continue;
            return i;
        }
        return -1;
    }

    private void captureKeyStates(class_310 client) {
        this.wasForwardPressed = this.isCurrentlyPressed(client, client.field_1690.field_1894);
        this.wasBackPressed = this.isCurrentlyPressed(client, client.field_1690.field_1881);
        this.wasLeftPressed = this.isCurrentlyPressed(client, client.field_1690.field_1913);
        this.wasRightPressed = this.isCurrentlyPressed(client, client.field_1690.field_1849);
        this.wasJumpPressed = this.isCurrentlyPressed(client, client.field_1690.field_1903);
        this.wasSprintPressed = this.isCurrentlyPressed(client, client.field_1690.field_1867);
    }

    private void stopPlayerInput(class_310 client) {
        client.field_1724.method_5728(false);
        if (client.field_1690 == null) {
            return;
        }
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1881.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
        this.keysOverridden = true;
    }

    private void restoreKeyStates(class_310 client) {
        if (!this.keysOverridden || client.field_1690 == null) {
            return;
        }
        client.field_1690.field_1894.method_23481(this.wasForwardPressed && this.isCurrentlyPressed(client, client.field_1690.field_1894));
        client.field_1690.field_1881.method_23481(this.wasBackPressed && this.isCurrentlyPressed(client, client.field_1690.field_1881));
        client.field_1690.field_1913.method_23481(this.wasLeftPressed && this.isCurrentlyPressed(client, client.field_1690.field_1913));
        client.field_1690.field_1849.method_23481(this.wasRightPressed && this.isCurrentlyPressed(client, client.field_1690.field_1849));
        client.field_1690.field_1903.method_23481(this.wasJumpPressed && this.isCurrentlyPressed(client, client.field_1690.field_1903));
        client.field_1690.field_1867.method_23481(this.wasSprintPressed && this.isCurrentlyPressed(client, client.field_1690.field_1867));
        this.keysOverridden = false;
    }

    private boolean isCurrentlyPressed(class_310 client, class_304 key) {
        if (client.method_22683() == null || key == null) {
            return false;
        }
        return class_3675.method_15987((class_1041)client.method_22683(), (int)class_3675.method_15981((String)key.method_1428()).method_1444());
    }

    private void clearReturnState() {
        this.previousOffhandStack = class_1799.field_8037;
        this.previousOffhandSourceSlot = -1;
        this.needsReturn = false;
    }

    private void resetState() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            this.restoreKeyStates(client);
        }
        this.savedSlot = -1;
        this.totemSlot = -1;
        this.actionStartTime = 0L;
        this.phase = Phase.READY;
        this.keysOverridden = false;
    }

    private static enum Phase {
        READY,
        SLOWING_DOWN,
        SWAP_TOTEM,
        AWAIT_SWITCH,
        RESTORE_SLOT,
        RETURN_SLOWING_DOWN,
        RETURN_ITEM,
        SPEEDING_UP;

    }
}

