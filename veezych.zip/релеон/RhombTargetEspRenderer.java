/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_4588
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_7833
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 */
package releon.ru.utils.render.world.targetesp;

import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.pipeline.ClientPipelines;
import releon.ru.utils.render.world.targetesp.TargetEspRenderContext;

public final class RhombTargetEspRenderer {
    private static final class_2960 RHOMB_TEXTURE = class_2960.method_60655((String)"releon", (String)"textures/world/cube.png");

    private RhombTargetEspRenderer() {
    }

    public static void render(class_4587 stack, class_4597.class_4598 provider, TargetEspRenderContext context) {
        class_4588 consumer = provider.method_73477(ClientPipelines.ROMB_ESP.apply(RHOMB_TEXTURE));
        Quaternionf camRot = class_310.method_1551().field_1773.method_19418().method_23767();
        stack.method_22903();
        stack.method_46416(0.0f, context.target().method_17682() / 2.0f, 0.0f);
        stack.method_22907((Quaternionfc)camRot);
        float timeRotation = (float)(context.frameTimeMs() % 6283L) / 1000.0f;
        stack.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees(class_3532.method_15374((double)timeRotation) * 360.0f));
        stack.method_22905(0.35f, 0.35f, 1.0f);
        int c1 = ColorUtil.withAlpha(context.primaryColor(), (int)(255.0f * context.alpha()));
        int c2 = ColorUtil.withAlpha(context.secondaryColor(), (int)(255.0f * context.alpha()));
        class_4587.class_4665 entry = stack.method_23760();
        consumer.method_56824(entry, -1.0f, -1.0f, 0.0f).method_22913(0.0f, 0.0f).method_39415(c2);
        consumer.method_56824(entry, -1.0f, 1.0f, 0.0f).method_22913(0.0f, 1.0f).method_39415(c1);
        consumer.method_56824(entry, 1.0f, 1.0f, 0.0f).method_22913(1.0f, 1.0f).method_39415(c2);
        consumer.method_56824(entry, 1.0f, -1.0f, 0.0f).method_22913(1.0f, 0.0f).method_39415(c1);
        stack.method_22909();
    }

    public static void endBatch(class_4597.class_4598 provider) {
        provider.method_22994(ClientPipelines.ROMB_ESP.apply(RHOMB_TEXTURE));
    }
}

