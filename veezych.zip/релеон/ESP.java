/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1531
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_5498
 *  net.minecraft.class_7923
 *  net.minecraft.class_8113$class_8123
 */
package releon.ru.api.module.impl.visual;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_7923;
import net.minecraft.class_8113;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.DrawEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AntiBot;
import releon.ru.api.module.impl.visual.esp.EspColors;
import releon.ru.api.module.impl.visual.esp.EspGeometry;
import releon.ru.api.module.impl.visual.esp.EspHealthTracker;
import releon.ru.api.module.impl.visual.esp.EspTagRenderer;
import releon.ru.api.module.impl.visual.esp.EspVisualRenderer;
import releon.ru.api.module.impl.visual.esp.PlayerTagResolver;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.render.item.RenderItem;
import releon.ru.utils.repository.friend.FriendUtils;

public final class ESP
extends Module {
    private static final Comparator<RenderEntry> RENDER_DISTANCE_COMPARATOR = Comparator.comparingDouble(RenderEntry::distanceSqr).reversed();
    private static final Comparator<CompactItemRowAccumulator> COMPACT_ITEM_ROW_COMPARATOR = Comparator.comparing(CompactItemRowAccumulator::id).thenComparing(CompactItemRowAccumulator::name);
    private final MultiModeSetting targets = this.register(new MultiModeSetting("Targets", "Entities rendered by ESP.", new String[]{"Players", "Items"}, "Players", "Items"));
    private final MultiModeSetting elements = this.register(new MultiModeSetting("Render", "ESP parts to draw.", new String[]{"Name", "Potions", "Equipment"}, "Name", "Potions", "Equipment"));
    private final MultiModeSetting tagElements = this.register(new MultiModeSetting("Tag Elements", "Parts shown inside player name tags.", new String[]{"Head", "Friend Prefix", "Donation", "Prefix", "Suffix", "Health"}, "Head", "Friend Prefix", "Donation", "Prefix", "Suffix", "Health"));
    private final ModeSetting itemMode = this.register(new ModeSetting("Items Mode", "Ground item ESP label style.", "Normal", "Normal", "Compact"));
    private final NumberSetting range = this.register(new NumberSetting("Range", "Maximum ESP render distance.", 128.0, 16.0, 256.0, 1.0));
    private final ColorSetting playerColor = this.register(new ColorSetting("Player Color", "Player ESP color.", new Color(127, 242, 255, 210)));
    private final ColorSetting friendColor = this.register(new ColorSetting("Friend Color", "Friend ESP color.", new Color(70, 255, 120, 220)));
    private static ESP instance;
    private final List<class_1297> trackedEntities = new ArrayList<class_1297>();
    private final Set<class_1297> seenEntities = Collections.newSetFromMap(new IdentityHashMap());
    private final List<RenderEntry> renderEntries = new ArrayList<RenderEntry>();
    private final List<RenderEntry> compactItemEntries = new ArrayList<RenderEntry>();
    private final List<CompactItemCluster> compactItemClusters = new ArrayList<CompactItemCluster>();
    private final EspHealthTracker healthTracker = new EspHealthTracker();
    private final PlayerTagResolver playerTagResolver = new PlayerTagResolver();
    private final EspTagRenderer tagRenderer = new EspTagRenderer(this.playerTagResolver, this.healthTracker);

    public ESP() {
        super("ESP", "Highlights players and items through walls.", ModuleCategory.VISUAL);
        instance = this;
    }

    public static boolean shouldHideVanillaName(class_1297 entity) {
        return instance != null && instance.isEnabled() && instance.shouldHideVanillaNameInternal(entity);
    }

    public static boolean shouldSuppressServerTagEntity(class_1297 entity) {
        return instance != null && instance.isEnabled() && instance.shouldSuppressServerTagEntityInternal(entity);
    }

    public static void captureServerHealth(class_1297 entity, class_2561 scoreText) {
        if (instance != null && instance.isEnabled()) {
            ESP.instance.healthTracker.capture(entity, scoreText);
        }
    }

    public static Float resolveHudHealth(class_1309 entity) {
        return ESP.resolveHudHealth(entity, true);
    }

    public static Float resolveHudHealth(class_1309 entity, boolean includeAbsorption) {
        return instance != null && instance.isEnabled() && entity != null ? Float.valueOf(ESP.instance.healthTracker.resolveDisplayHealth(entity, includeAbsorption)) : null;
    }

    @Override
    public void onTick(class_310 client) {
        this.healthTracker.prune();
        this.rebuildTargets(client);
    }

    @Override
    protected void onDisable() {
        this.trackedEntities.clear();
        this.healthTracker.clear();
    }

    @SubscribeEvent
    private void onWorldRender(WorldRenderEvent event) {
        if (!this.elements.isSelected("3D Box") || ESP.mc.field_1724 == null || ESP.mc.field_1687 == null) {
            return;
        }
        for (class_1297 entity : this.trackedEntities) {
            if (!this.isValidTarget(entity)) continue;
            class_238 box = EspGeometry.interpolatedBox(entity, event.getPartialTicks()).method_1014(0.02);
            int color = this.colorFor(entity);
            EspVisualRenderer.draw3DCornerBox(box, color, EspVisualRenderer.resolve3DLineWidth(mc, box));
        }
    }

    @SubscribeEvent
    private void onDraw(DrawEvent event) {
        if (ESP.mc.field_1724 == null || ESP.mc.field_1687 == null || mc.method_22683() == null) {
            return;
        }
        EspGeometry.ProjectionContext context = EspGeometry.createProjectionContext(mc, event.getPartialTicks());
        if (context == null) {
            return;
        }
        boolean draw2DBox = this.elements.isSelected("2D Box");
        boolean drawName = this.elements.isSelected("Name");
        boolean drawHealth = this.tagElements.isSelected("Health");
        boolean drawPotions = this.elements.isSelected("Potions");
        boolean drawEquipment = this.elements.isSelected("Equipment");
        if (!(draw2DBox || drawName || drawPotions || drawEquipment)) {
            return;
        }
        List<RenderEntry> entries = this.collectRenderEntries(context);
        if (entries.isEmpty()) {
            return;
        }
        if (entries.size() > 1) {
            entries.sort(RENDER_DISTANCE_COMPARATOR);
        }
        class_332 graphics = event.getGraphics();
        if (drawEquipment || drawName) {
            RenderItem.beginFrame(graphics);
        }
        boolean compactItems = this.itemMode.is("Compact");
        this.compactItemEntries.clear();
        for (RenderEntry entry : entries) {
            class_1297 entity = entry.entity();
            EspGeometry.ScreenBox box = entry.screenBox();
            float alpha = this.alphaForDistance(entry.distanceSqr());
            if (draw2DBox) {
                EspVisualRenderer.draw2DBox(box, entry.color(), alpha);
            }
            if (drawEquipment && entity instanceof class_1657) {
                class_1657 player = (class_1657)entity;
                this.tagRenderer.drawEquipment(player, box, entry.topAnchor(), alpha);
            }
            if (drawPotions && entity instanceof class_1309) {
                class_1309 living = (class_1309)entity;
                this.tagRenderer.drawPotions(living, box, alpha);
            }
            if (compactItems && drawName && entity instanceof class_1542) {
                this.compactItemEntries.add(entry);
                continue;
            }
            if (!drawName) continue;
            this.tagRenderer.drawTag(entity, box, entry.topAnchor(), drawHealth, alpha, this.tagElements, mc, graphics);
        }
        if (!this.compactItemEntries.isEmpty()) {
            this.drawCompactItemTags(this.compactItemEntries, graphics, context);
        }
        if (drawEquipment || drawName) {
            RenderItem.flush();
        }
    }

    private void drawCompactItemTags(List<RenderEntry> itemEntries, class_332 graphics, EspGeometry.ProjectionContext context) {
        this.compactItemClusters.clear();
        for (RenderEntry entry : itemEntries) {
            class_1542 item;
            class_243 position;
            class_1297 class_12972 = entry.entity();
            if (!(class_12972 instanceof class_1542) || !EspGeometry.isFinite(position = (item = (class_1542)class_12972).method_30950(context.tickDelta()))) continue;
            CompactItemCluster cluster = null;
            for (CompactItemCluster candidate : this.compactItemClusters) {
                if (!candidate.accepts(position)) continue;
                cluster = candidate;
                break;
            }
            if (cluster == null) {
                cluster = new CompactItemCluster(position);
                this.compactItemClusters.add(cluster);
            }
            cluster.add(item, position, this.alphaForDistance(entry.distanceSqr()));
        }
        for (CompactItemCluster cluster : this.compactItemClusters) {
            class_243 anchor = cluster.anchor();
            EspGeometry.ScreenPoint screen = EspGeometry.projectWorldToScreenSpace(anchor, context);
            if (screen == null || screen.z() < 0.0 || screen.z() > 1.0) continue;
            double marginX = (double)context.screenWidth() * 0.35;
            double marginY = (double)context.screenHeight() * 0.35;
            if (screen.x() < -marginX || screen.x() > (double)context.screenWidth() + marginX || screen.y() < -marginY || screen.y() > (double)context.screenHeight() + marginY) continue;
            EspVisualRenderer.drawCompactItemTag(cluster.rows(), screen.x(), screen.y(), cluster.alpha(), graphics);
        }
    }

    private List<RenderEntry> collectRenderEntries(EspGeometry.ProjectionContext context) {
        this.renderEntries.clear();
        for (class_1297 entity : this.trackedEntities) {
            EspGeometry.ScreenBox screenBox;
            if (!this.isValidTarget(entity) || (screenBox = EspGeometry.projectEntityBox(entity, context)) == null || !EspGeometry.isOnScreen(screenBox, context)) continue;
            EspGeometry.ScreenAnchor topAnchor = EspGeometry.resolveTopAnchor(entity, context, screenBox);
            class_243 interpolated = entity.method_30950(context.tickDelta());
            this.renderEntries.add(new RenderEntry(entity, screenBox, topAnchor, context.cameraPos().method_1025(interpolated), this.colorFor(entity)));
        }
        return this.renderEntries;
    }

    private void rebuildTargets(class_310 client) {
        this.trackedEntities.clear();
        if (client == null || client.field_1687 == null || client.field_1724 == null) {
            return;
        }
        this.seenEntities.clear();
        if (this.targets.isSelected("Players")) {
            for (class_1657 player : client.field_1687.method_18456()) {
                this.addIfValid(this.seenEntities, (class_1297)player);
            }
        }
        if (this.targets.isSelected("Items")) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (entity instanceof class_1657) continue;
                this.addIfValid(this.seenEntities, entity);
            }
        }
    }

    private void addIfValid(Set<class_1297> seen, class_1297 entity) {
        if (this.isValidTarget(entity) && seen.add(entity)) {
            this.trackedEntities.add(entity);
        }
    }

    private boolean isValidTarget(class_1297 entity) {
        if (entity == null || entity.method_31481() || ESP.mc.field_1724 == null || ESP.mc.field_1687 == null) {
            return false;
        }
        if (entity == ESP.mc.field_1724 && ESP.mc.field_1690.method_31044() == class_5498.field_26664) {
            return false;
        }
        if (this.range.getFloat() > 0.0f && entity != ESP.mc.field_1724 && ESP.mc.field_1724.method_5858(entity) > (double)(this.range.getFloat() * this.range.getFloat())) {
            return false;
        }
        if (!EspGeometry.isFinite(entity.method_73189())) {
            return false;
        }
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            return this.targets.isSelected("Players") && !player.method_7325() && !AntiBot.shouldIgnore(player);
        }
        if (entity instanceof class_1542) {
            class_1542 item = (class_1542)entity;
            return this.targets.isSelected("Items") && !item.method_6983().method_7960();
        }
        return false;
    }

    private boolean shouldHideVanillaNameInternal(class_1297 entity) {
        if (!this.shouldHidePlayerLabels()) {
            return false;
        }
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            return this.isPlayerLabelTarget(player);
        }
        return this.isServerTagEntity(entity) && this.isPlayerServerTagEntity(entity);
    }

    private boolean shouldSuppressServerTagEntityInternal(class_1297 entity) {
        if (!this.shouldHidePlayerLabels() || !this.isServerTagEntity(entity)) {
            return false;
        }
        return this.isPlayerServerTagEntity(entity);
    }

    private boolean shouldHidePlayerLabels() {
        return this.elements.isSelected("Name") && this.targets.isSelected("Players") && ESP.mc.field_1724 != null && ESP.mc.field_1687 != null;
    }

    private boolean isPlayerLabelTarget(class_1657 player) {
        if (player == null || player.method_31481() || player.method_7325() || AntiBot.shouldIgnore(player)) {
            return false;
        }
        if (player == ESP.mc.field_1724 && ESP.mc.field_1690.method_31044() == class_5498.field_26664) {
            return false;
        }
        if (this.range.getFloat() > 0.0f && player != ESP.mc.field_1724 && ESP.mc.field_1724.method_5858((class_1297)player) > (double)(this.range.getFloat() * this.range.getFloat())) {
            return false;
        }
        return EspGeometry.isFinite(player.method_73189());
    }

    private boolean isServerTagEntity(class_1297 entity) {
        if (entity == null || entity instanceof class_1657) {
            return false;
        }
        if (entity instanceof class_8113.class_8123) {
            return true;
        }
        if (entity instanceof class_1531) {
            class_1531 armorStand = (class_1531)entity;
            return armorStand.method_16914() || armorStand.method_5733() || armorStand.method_6912();
        }
        return entity.method_16914() && entity.method_5733();
    }

    private boolean isPlayerServerTagEntity(class_1297 tagEntity) {
        if (tagEntity == null || !EspGeometry.isFinite(tagEntity.method_73189())) {
            return false;
        }
        String tagText = this.serverTagText(tagEntity);
        if (tagText.isBlank()) {
            return false;
        }
        for (class_1657 player : ESP.mc.field_1687.method_18456()) {
            if (!this.isPlayerLabelTarget(player) || !this.isAttachedPlayerServerTag(tagEntity, player, tagText)) continue;
            return true;
        }
        return false;
    }

    private boolean isAttachedPlayerServerTag(class_1297 tagEntity, class_1657 player, String tagText) {
        if (this.containsPlayerName(tagText, player)) {
            return this.isNearPlayerNameLabel(tagEntity, player);
        }
        return this.looksLikeHealthTag(tagText) && this.isNearPlayerHealthLabel(tagEntity, player);
    }

    private boolean isNearPlayerNameLabel(class_1297 tagEntity, class_1657 player) {
        double horizontalLimit;
        double dz;
        double dx = tagEntity.method_23317() - player.method_23317();
        if (dx * dx + (dz = tagEntity.method_23321() - player.method_23321()) * dz > (horizontalLimit = 1.1) * horizontalLimit) {
            return false;
        }
        double aboveFeet = tagEntity.method_23318() - player.method_23318();
        return aboveFeet >= 1.2 && aboveFeet <= 4.4;
    }

    private boolean isNearPlayerHealthLabel(class_1297 tagEntity, class_1657 player) {
        double horizontalLimit;
        double dz;
        double dx = tagEntity.method_23317() - player.method_23317();
        if (dx * dx + (dz = tagEntity.method_23321() - player.method_23321()) * dz > (horizontalLimit = 0.95) * horizontalLimit) {
            return false;
        }
        double aboveFeet = tagEntity.method_23318() - player.method_23318();
        return aboveFeet >= 1.25 && aboveFeet <= 3.35;
    }

    private String serverTagText(class_1297 entity) {
        class_2561 text = null;
        if (entity instanceof class_8113.class_8123) {
            class_8113.class_8123 textDisplay = (class_8113.class_8123)entity;
            text = textDisplay.method_48915();
        }
        if (text == null) {
            text = entity.method_5797();
        }
        return this.cleanServerTagText(text == null ? "" : text.getString());
    }

    private boolean containsPlayerName(String tagText, class_1657 player) {
        String compactTag = this.compactSearchText(tagText);
        String scoreboardName = this.compactSearchText(player.method_5820());
        String displayName = this.compactSearchText(player.method_5477().getString());
        return !scoreboardName.isBlank() && compactTag.contains(scoreboardName) || !displayName.isBlank() && compactTag.contains(displayName);
    }

    private boolean looksLikeHealthTag(String tagText) {
        String cleaned = this.cleanServerTagText(tagText).toLowerCase(Locale.ROOT);
        if (cleaned.isBlank()) {
            return false;
        }
        boolean hasHealthMarker = cleaned.contains("hp") || cleaned.contains("\u0445\u043f") || cleaned.indexOf(10084) >= 0 || cleaned.indexOf(9829) >= 0;
        int digits = 0;
        int invalid = 0;
        for (int i = 0; i < cleaned.length(); ++i) {
            char c = cleaned.charAt(i);
            if (Character.isDigit(c)) {
                ++digits;
                continue;
            }
            if (Character.isWhitespace(c) || c == '.' || c == ',' || c == '/' || c == '\u2764' || c == '\u2665' || c == '[' || c == ']' || c == '(' || c == ')' || c == 'h' || c == 'p' || c == '\u0445' || c == '\u043f') continue;
            ++invalid;
        }
        return digits > 0 && invalid == 0 && (hasHealthMarker || cleaned.trim().length() <= 4);
    }

    private String cleanServerTagText(String text) {
        if (text == null || text.isBlank()) {
            return "";
        }
        StringBuilder builder = new StringBuilder(text.length());
        boolean skipFormatting = false;
        for (int i = 0; i < text.length(); ++i) {
            char c = text.charAt(i);
            if (skipFormatting) {
                skipFormatting = false;
                continue;
            }
            if (c == '\u00a7') {
                skipFormatting = true;
                continue;
            }
            if (Character.isISOControl(c)) continue;
            builder.append(c);
        }
        return builder.toString().trim();
    }

    private String compactSearchText(String text) {
        String cleaned = this.cleanServerTagText(text).toLowerCase(Locale.ROOT);
        if (cleaned.isBlank()) {
            return "";
        }
        StringBuilder builder = new StringBuilder(cleaned.length());
        for (int i = 0; i < cleaned.length(); ++i) {
            char c = cleaned.charAt(i);
            if (!Character.isLetterOrDigit(c) && c != '_') continue;
            builder.append(c);
        }
        return builder.toString();
    }

    private int colorFor(class_1297 entity) {
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            return FriendUtils.isFriend((class_1297)player) ? ((Color)this.friendColor.getValue()).getRGB() : ((Color)this.playerColor.getValue()).getRGB();
        }
        return EspColors.ITEM;
    }

    private float alphaForDistance(double distanceSqr) {
        double distance = Math.sqrt(Math.max(0.0, distanceSqr));
        return (float)class_3532.method_15350((double)(1.0 - (distance - 96.0) / 80.0), (double)0.48, (double)1.0);
    }

    private static String cleanItemName(String text) {
        if (text == null || text.isBlank()) {
            return "";
        }
        StringBuilder builder = new StringBuilder(text.length());
        boolean skipFormatting = false;
        for (int i = 0; i < text.length(); ++i) {
            char c = text.charAt(i);
            if (skipFormatting) {
                skipFormatting = false;
                continue;
            }
            if (c == '\u00a7') {
                skipFormatting = true;
                continue;
            }
            if (Character.isISOControl(c)) continue;
            builder.append(c);
        }
        return builder.toString().trim();
    }

    private record RenderEntry(class_1297 entity, EspGeometry.ScreenBox screenBox, EspGeometry.ScreenAnchor topAnchor, double distanceSqr, int color) {
    }

    private static final class CompactItemCluster {
        private double worldX;
        private double worldY;
        private double worldZ;
        private double anchorY;
        private float alpha;
        private int entries;
        private final Map<CompactItemKey, CompactItemRowAccumulator> rows = new LinkedHashMap<CompactItemKey, CompactItemRowAccumulator>();
        private final List<CompactItemRowAccumulator> sortedRows = new ArrayList<CompactItemRowAccumulator>();
        private final List<EspVisualRenderer.ItemTagRow> renderRows = new ArrayList<EspVisualRenderer.ItemTagRow>();

        private CompactItemCluster(class_243 first) {
            this.worldX = first.field_1352;
            this.worldY = first.field_1351;
            this.worldZ = first.field_1350;
            this.anchorY = first.field_1351 + 0.72;
        }

        private boolean accepts(class_243 position) {
            double dx = position.field_1352 - this.worldX;
            double dy = Math.abs(position.field_1351 - this.worldY);
            double dz = position.field_1350 - this.worldZ;
            return dx * dx + dz * dz <= 7.29 && dy <= 1.75;
        }

        private void add(class_1542 item, class_243 position, float entryAlpha) {
            double nextWeight = (double)this.entries + 1.0;
            this.worldX = (this.worldX * (double)this.entries + position.field_1352) / nextWeight;
            this.worldY = (this.worldY * (double)this.entries + position.field_1351) / nextWeight;
            this.worldZ = (this.worldZ * (double)this.entries + position.field_1350) / nextWeight;
            this.anchorY = Math.max(this.anchorY, position.field_1351 + 0.72);
            this.alpha = Math.max(this.alpha, entryAlpha);
            ++this.entries;
            class_1799 stack = item.method_6983();
            String name = ESP.cleanItemName(stack.method_7964().getString());
            String id = class_7923.field_41178.method_10221((Object)stack.method_7909()).toString();
            CompactItemKey key = new CompactItemKey(id, name);
            this.rows.computeIfAbsent(key, ignored -> new CompactItemRowAccumulator(stack.method_7972(), id, name)).add(stack.method_7947());
        }

        private List<EspVisualRenderer.ItemTagRow> rows() {
            this.sortedRows.clear();
            this.sortedRows.addAll(this.rows.values());
            if (this.sortedRows.size() > 1) {
                this.sortedRows.sort(COMPACT_ITEM_ROW_COMPARATOR);
            }
            this.renderRows.clear();
            for (CompactItemRowAccumulator row : this.sortedRows) {
                this.renderRows.add(new EspVisualRenderer.ItemTagRow(row.stack(), row.name(), row.count()));
            }
            return this.renderRows;
        }

        private class_243 anchor() {
            return new class_243(this.worldX, this.anchorY, this.worldZ);
        }

        private float alpha() {
            return this.alpha;
        }
    }

    private static final class CompactItemRowAccumulator {
        private final class_1799 stack;
        private final String id;
        private final String name;
        private int count;

        private CompactItemRowAccumulator(class_1799 stack, String id, String name) {
            this.stack = stack;
            this.id = id;
            this.name = name;
            this.stack.method_7939(1);
        }

        private void add(int amount) {
            this.count = Math.max(1, Math.min(Integer.MAX_VALUE, this.count + Math.max(1, amount)));
        }

        private String id() {
            return this.id;
        }

        private class_1799 stack() {
            return this.stack;
        }

        private String name() {
            return this.name;
        }

        private int count() {
            return this.count;
        }
    }

    private record CompactItemKey(String id, String name) {
    }
}

