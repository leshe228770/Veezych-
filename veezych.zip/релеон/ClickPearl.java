/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1802
 *  net.minecraft.class_310
 */
package releon.ru.api.module.impl.player;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;
import releon.ru.utils.chat.ChatMessage;
import releon.ru.utils.inventory.lookup.InventoryUtils;

public final class ClickPearl
extends Module {
    private static final long PRE_SWAP_DELAY_MS = 35L;
    private static final long PRE_USE_DELAY_MS = 35L;
    private static final long PRE_RESTORE_DELAY_MS = 35L;
    private static ClickPearl instance;
    private final BindSetting keySetting = this.register(new BindSetting("\u041a\u043d\u043e\u043f\u043a\u0430", "\u041a\u043d\u043e\u043f\u043a\u0430 \u0434\u043b\u044f \u0431\u0440\u043e\u0441\u043a\u0430 \u043f\u0435\u0440\u043a\u0438.", KeyBind.keyboard(-1)));
    private boolean throwPearl;
    private boolean lastBindDown;
    private long lastUseTime;
    private long actionTimer;
    private int previousSlot = -1;
    private int pendingHotbarSlot = -1;
    private int pendingInventorySlotId = -1;
    private boolean keysOverridden;
    private boolean wasForwardPressed;
    private boolean wasBackPressed;
    private boolean wasLeftPressed;
    private boolean wasRightPressed;
    private boolean wasJumpPressed;
    private ThrowState throwState = ThrowState.IDLE;
    private ThrowMode throwMode = ThrowMode.NONE;

    public ClickPearl() {
        super("ClickPearl", "Click Pearl", ModuleCategory.PLAYER);
        instance = this;
    }

    public static boolean shouldBypassInventoryMove() {
        return instance != null && ClickPearl.instance.throwMode == ThrowMode.INVENTORY && ClickPearl.instance.throwState != ThrowState.IDLE;
    }

    @Override
    protected void onDisable() {
        this.throwPearl = false;
        this.lastUseTime = 0L;
        this.lastBindDown = false;
        this.restoreMovement();
        this.resetThrowState();
    }

    @SubscribeEvent
    private void onPreTick(TickEvent.Pre event) {
        class_310 client = event.getClient();
        if (ClickPearl.mc.field_1724 == null || ClickPearl.mc.field_1687 == null) {
            this.resetThrowState();
            return;
        }
        this.updateBindState(client);
        if (this.throwState != ThrowState.IDLE) {
            this.maintainMovementStop();
            this.processThrow();
            return;
        }
        if (!this.throwPearl || ClickPearl.mc.field_1755 != null) {
            return;
        }
        if (System.currentTimeMillis() - this.lastUseTime < 200L) {
            return;
        }
        this.throwPearl = false;
        if (ClickPearl.mc.field_1724.method_7357().method_7904(class_1802.field_8634.method_7854())) {
            return;
        }
        if (ClickPearl.mc.field_1724.method_6079().method_7909() == class_1802.field_8634) {
            this.startThrow(ThrowMode.OFFHAND, -1, -1);
            return;
        }
        int hotbarSlot = this.findPearlInHotbar();
        if (hotbarSlot != -1) {
            this.startThrow(ThrowMode.HOTBAR, hotbarSlot, -1);
            return;
        }
        int inventorySlot = this.findPearlInInventory();
        if (inventorySlot != -1) {
            this.startThrow(ThrowMode.INVENTORY, -1, InventoryUtils.wrapSlot(inventorySlot));
            return;
        }
        ChatMessage.brandmessage("\u041d\u0435\u0442\u0443 \u0436\u0435\u043c\u0447\u0443\u0433\u0430");
    }

    private void updateBindState(class_310 client) {
        if (client.method_22683() == null || client.field_1755 != null) {
            this.lastBindDown = false;
            return;
        }
        boolean bindDown = ((KeyBind)this.keySetting.getValue()).isDown(client.method_22683().method_4490());
        if (bindDown && !this.lastBindDown) {
            this.throwPearl = true;
        }
        this.lastBindDown = bindDown;
    }

    private void startThrow(ThrowMode mode, int hotbarSlot, int inventorySlotId) {
        this.throwMode = mode;
        this.previousSlot = ClickPearl.mc.field_1724.method_31548().method_67532();
        this.pendingHotbarSlot = hotbarSlot;
        this.pendingInventorySlotId = inventorySlotId;
        this.wasForwardPressed = ClickPearl.mc.field_1690.field_1894.method_1434();
        this.wasBackPressed = ClickPearl.mc.field_1690.field_1881.method_1434();
        this.wasLeftPressed = ClickPearl.mc.field_1690.field_1913.method_1434();
        this.wasRightPressed = ClickPearl.mc.field_1690.field_1849.method_1434();
        this.wasJumpPressed = ClickPearl.mc.field_1690.field_1903.method_1434();
        this.keysOverridden = true;
        this.maintainMovementStop();
        if (ClickPearl.mc.field_1724.method_5624()) {
            ClickPearl.mc.field_1724.method_5728(false);
        }
        this.throwState = ThrowState.WAIT_BEFORE_SWAP;
        this.actionTimer = System.currentTimeMillis();
    }

    private int findPearlInHotbar() {
        for (int i = 0; i < 9; ++i) {
            if (ClickPearl.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8634) continue;
            return i;
        }
        return -1;
    }

    private int findPearlInInventory() {
        for (int i = 9; i < 36; ++i) {
            if (ClickPearl.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8634) continue;
            return i;
        }
        return -1;
    }

    private void processThrow() {
        switch (this.throwState.ordinal()) {
            case 1: {
                if (System.currentTimeMillis() - this.actionTimer < 35L) {
                    return;
                }
                switch (this.throwMode.ordinal()) {
                    case 1: 
                    case 2: {
                        break;
                    }
                    case 3: {
                        this.startInventoryPearlSwap();
                        break;
                    }
                    default: {
                        this.resetThrowState();
                        return;
                    }
                }
                this.throwState = ThrowState.WAIT_BEFORE_USE;
                this.actionTimer = System.currentTimeMillis();
                break;
            }
            case 2: {
                if (System.currentTimeMillis() - this.actionTimer < 35L) {
                    return;
                }
                switch (this.throwMode.ordinal()) {
                    case 1: {
                        this.useOffhandPearl();
                        break;
                    }
                    case 2: {
                        this.startHotbarPearlUse();
                        break;
                    }
                    case 3: {
                        this.useInventoryPearl();
                        break;
                    }
                    default: {
                        this.resetThrowState();
                        return;
                    }
                }
                this.lastUseTime = System.currentTimeMillis();
                this.throwState = ThrowState.WAIT_BEFORE_RESTORE;
                this.actionTimer = System.currentTimeMillis();
                break;
            }
            case 3: {
                if (System.currentTimeMillis() - this.actionTimer < 35L) {
                    return;
                }
                switch (this.throwMode.ordinal()) {
                    case 2: {
                        this.finishHotbarPearlUse();
                        break;
                    }
                    case 3: {
                        this.finishInventoryPearlUse();
                        break;
                    }
                }
                this.restoreMovement();
                this.resetThrowState();
                break;
            }
        }
    }

    private void useOffhandPearl() {
        ClickPearl.mc.field_1761.method_2919((class_1657)ClickPearl.mc.field_1724, class_1268.field_5810);
        ClickPearl.mc.field_1724.method_6104(class_1268.field_5810);
    }

    private void startHotbarPearlUse() {
        this.maintainMovementStop();
        if (this.pendingHotbarSlot != this.previousSlot) {
            InventoryUtils.syncSelectedHotbarSlot(this.pendingHotbarSlot);
        }
        ClickPearl.mc.field_1761.method_2919((class_1657)ClickPearl.mc.field_1724, class_1268.field_5808);
        ClickPearl.mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void finishHotbarPearlUse() {
        this.maintainMovementStop();
        if (this.pendingHotbarSlot != this.previousSlot && this.previousSlot != -1) {
            InventoryUtils.syncSelectedHotbarSlot(this.previousSlot);
        }
    }

    private void startInventoryPearlSwap() {
        if (this.pendingInventorySlotId == -1 || this.previousSlot == -1) {
            return;
        }
        this.maintainMovementStop();
        InventoryUtils.click(this.pendingInventorySlotId, this.previousSlot, class_1713.field_7791);
    }

    private void useInventoryPearl() {
        if (this.pendingInventorySlotId == -1 || this.previousSlot == -1) {
            return;
        }
        this.maintainMovementStop();
        ClickPearl.mc.field_1761.method_2919((class_1657)ClickPearl.mc.field_1724, class_1268.field_5808);
        ClickPearl.mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void finishInventoryPearlUse() {
        if (this.pendingInventorySlotId == -1 || this.previousSlot == -1) {
            return;
        }
        this.maintainMovementStop();
        InventoryUtils.click(this.pendingInventorySlotId, this.previousSlot, class_1713.field_7791);
        InventoryUtils.syncSelectedHotbarSlot(this.previousSlot);
    }

    private void maintainMovementStop() {
        ClickPearl.mc.field_1690.field_1894.method_23481(false);
        ClickPearl.mc.field_1690.field_1881.method_23481(false);
        ClickPearl.mc.field_1690.field_1913.method_23481(false);
        ClickPearl.mc.field_1690.field_1849.method_23481(false);
        ClickPearl.mc.field_1690.field_1903.method_23481(false);
        ClickPearl.mc.field_1690.field_1867.method_23481(false);
        if (ClickPearl.mc.field_1724.method_5624()) {
            ClickPearl.mc.field_1724.method_5728(false);
        }
    }

    private void restoreMovement() {
        if (!this.keysOverridden) {
            return;
        }
        ClickPearl.mc.field_1690.field_1894.method_23481(this.wasForwardPressed);
        ClickPearl.mc.field_1690.field_1881.method_23481(this.wasBackPressed);
        ClickPearl.mc.field_1690.field_1913.method_23481(this.wasLeftPressed);
        ClickPearl.mc.field_1690.field_1849.method_23481(this.wasRightPressed);
        ClickPearl.mc.field_1690.field_1903.method_23481(this.wasJumpPressed);
        this.keysOverridden = false;
    }

    private void resetThrowState() {
        this.throwState = ThrowState.IDLE;
        this.throwMode = ThrowMode.NONE;
        this.actionTimer = 0L;
        this.previousSlot = -1;
        this.pendingHotbarSlot = -1;
        this.pendingInventorySlotId = -1;
        this.keysOverridden = false;
    }

    private static enum ThrowState {
        IDLE,
        WAIT_BEFORE_SWAP,
        WAIT_BEFORE_USE,
        WAIT_BEFORE_RESTORE;

    }

    private static enum ThrowMode {
        NONE,
        OFFHAND,
        HOTBAR,
        INVENTORY;

    }
}

