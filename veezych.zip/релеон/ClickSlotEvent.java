/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1713
 */
package releon.ru.api.events.impl;

import net.minecraft.class_1713;
import releon.ru.api.events.CancellableEvent;

public final class ClickSlotEvent
extends CancellableEvent {
    private final int windowId;
    private final int slotId;
    private final int button;
    private final class_1713 actionType;

    public ClickSlotEvent(int windowId, int slotId, int button, class_1713 actionType) {
        this.windowId = windowId;
        this.slotId = slotId;
        this.button = button;
        this.actionType = actionType;
    }

    public int getWindowId() {
        return this.windowId;
    }

    public int getSlotId() {
        return this.slotId;
    }

    public int getButton() {
        return this.button;
    }

    public class_1713 getActionType() {
        return this.actionType;
    }
}

