/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 */
package releon.ru.api.module.impl.movement;

import net.minecraft.class_243;
import net.minecraft.class_310;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.move.MoveUtil;

public final class Fly
extends Module {
    private final ModeSetting mode = this.register(new ModeSetting("Mode", "Flight mode.", "Vanilla", "Vanilla", "Dragon"));
    private final NumberSetting horizontal = this.register(new NumberSetting("Horizontal", "Horizontal speed.", 1.0, 0.1, 5.0, 0.1));
    private final NumberSetting vertical = this.register(new NumberSetting("Vertical", "Vertical speed.", 0.6, 0.1, 3.0, 0.1));

    public Fly() {
        super("Fly", "Flight movement module.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }
        if (!(!this.mode.is("Dragon") || client.field_1724.method_31549().field_7478 && client.field_1724.method_31549().field_7479)) {
            return;
        }
        double[] dir = MoveUtil.calculateDirection((Double)this.horizontal.getValue());
        double y = 0.0;
        if (client.field_1690.field_1903.method_1434()) {
            y += ((Double)this.vertical.getValue()).doubleValue();
        }
        if (client.field_1690.field_1832.method_1434()) {
            y -= ((Double)this.vertical.getValue()).doubleValue();
        }
        if (!MoveUtil.hasPlayerMovement()) {
            dir[0] = 0.0;
            dir[1] = 0.0;
        }
        client.field_1724.method_18799(new class_243(dir[0], y, dir[1]));
    }
}

