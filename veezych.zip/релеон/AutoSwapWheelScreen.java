/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11908
 *  net.minecraft.class_11909
 *  net.minecraft.class_1799
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_437
 */
package releon.ru.api.module.impl.combat.autoswaputil;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import releon.ru.api.module.impl.combat.AutoSwap;
import releon.ru.utils.render.item.RenderItem;
import releon.ru.utils.render.item.RenderItemOptions;
import releon.ru.utils.render.ui.Render2D;

public class AutoSwapWheelScreen
extends class_437 {
    private static final float SECTOR_SIZE = 120.0f;
    private static final float SECTOR_GAP = 2.0f;
    private static final float SECTOR_DEGREE = 118.0f;
    private static final float OUTER_RADIUS_FACTOR = 0.23f;
    private static final float INNER_RADIUS_FACTOR = 0.6f;
    private static final float HOVER_PUSH = 8.0f;
    private static final float HOVER_EXPAND = 4.0f;
    private static final float OUTLINE_THICKNESS = 0.9f;
    private static final int ICON_SIZE = 16;
    private static final String CHANGE_ITEM_HINT = "\u041f\u041a\u041c - \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u043f\u0440\u0435\u0434\u043c\u0435\u0442";
    private final AutoSwap autoSwap;
    private final IconRect[] iconRects = new IconRect[3];
    private final class_1799[] lastStacks = new class_1799[3];
    private int hoveredSector = -1;

    public AutoSwapWheelScreen(AutoSwap autoSwap) {
        super((class_2561)class_2561.method_43473());
        this.autoSwap = autoSwap;
    }

    public boolean method_25421() {
        return false;
    }

    public boolean method_25422() {
        return true;
    }

    public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
    }

    protected void method_57734(class_332 graphics) {
    }

    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(null);
        }
    }

    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        Render2D.beginFrame(graphics);
        RenderItem.beginFrame(graphics);
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 336070664);
        float centerX = (float)this.field_22789 / 2.0f;
        float centerY = (float)this.field_22790 / 2.0f;
        float outerRadius = (float)Math.min(this.field_22789, this.field_22790) * 0.23f;
        float innerRadius = outerRadius * 0.6f;
        float iconRadius = (outerRadius + innerRadius) * 0.5f;
        this.hoveredSector = this.computeHoveredSector(mouseX, mouseY, centerX, centerY, innerRadius, outerRadius);
        for (int i = 0; i < 3; ++i) {
            IconRect rect;
            class_1799 stack;
            this.lastStacks[i] = class_1799.field_8037;
            this.iconRects[i] = null;
            this.lastStacks[i] = stack = this.autoSwap.getWheelSlotStack(i);
            float centerAngle = this.getSectorCenterAngle(i);
            double radians = Math.toRadians(centerAngle);
            float progress = i == this.hoveredSector ? 1.0f : 0.0f;
            float shift = 8.0f * progress;
            float expand = 4.0f * progress;
            float shiftedCenterX = centerX + (float)Math.cos(radians) * shift;
            float shiftedCenterY = centerY + (float)Math.sin(radians) * shift;
            float currentOuterRadius = outerRadius + expand;
            float currentInnerRadius = innerRadius;
            float currentThickness = currentOuterRadius - currentInnerRadius;
            float fixedX = Render2D.guiToFixed(shiftedCenterX - currentOuterRadius);
            float fixedY = Render2D.guiToFixed(shiftedCenterY - currentOuterRadius);
            float fixedSize = Render2D.guiToFixed(currentOuterRadius * 2.0f);
            float fixedThickness = Render2D.guiToFixed(currentThickness);
            int sectorColor = this.lerpColor(1871613582, -1428563495, progress);
            int outlineColor = this.lerpColor(-1866942280, -722144012, progress);
            Render2D.arc(fixedX, fixedY, fixedSize, fixedThickness, 118.0f, centerAngle, sectorColor);
            Render2D.arcOutline(fixedX, fixedY, fixedSize, fixedThickness, 118.0f, centerAngle, Render2D.guiToFixed(0.9f), 0, outlineColor);
            float iconX = shiftedCenterX + (float)Math.cos(radians) * iconRadius;
            float iconY = shiftedCenterY + (float)Math.sin(radians) * iconRadius;
            this.iconRects[i] = rect = new IconRect(class_3532.method_15375((float)(iconX - 8.0f)), class_3532.method_15375((float)(iconY - 8.0f)), 16, 16);
            if (!stack.method_7960()) {
                RenderItem.item(stack, Render2D.guiToFixed(iconX - 8.0f), Render2D.guiToFixed(iconY - 8.0f), Render2D.guiToFixed(16.0f), RenderItemOptions.noDecorations(1.0f));
                continue;
            }
            int plusColor = this.lerpColor(-1076505131, -1, progress);
            graphics.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)"+"), rect.x + rect.w / 2, rect.y + 4, plusColor);
        }
        graphics.method_27534(this.field_22793, (class_2561)class_2561.method_43470((String)CHANGE_ITEM_HINT), this.field_22789 / 2, class_3532.method_15375((float)(centerY + outerRadius + 20.0f)), -687865857);
        RenderItem.flush();
        Render2D.flush();
    }

    public boolean method_25404(class_11908 event) {
        if (event.comp_4795() == 256) {
            this.method_25419();
            return true;
        }
        return super.method_25404(event);
    }

    public boolean method_25402(class_11909 event, boolean doubleClick) {
        int selectedIndex = this.findSelectedIndex(event.comp_4798(), event.comp_4799());
        if (selectedIndex == -1) {
            return super.method_25402(event, doubleClick);
        }
        if (event.method_74245() == 1) {
            this.method_25419();
            this.autoSwap.startSelectingItem(selectedIndex);
            return true;
        }
        if (event.method_74245() == 0) {
            class_1799 stack = this.lastStacks[selectedIndex] == null ? class_1799.field_8037 : this.lastStacks[selectedIndex];
            this.method_25419();
            if (!stack.method_7960()) {
                this.autoSwap.startSwapToItemStack(stack);
            }
            return true;
        }
        return super.method_25402(event, doubleClick);
    }

    private int findSelectedIndex(double mouseX, double mouseY) {
        for (int i = 0; i < this.iconRects.length; ++i) {
            IconRect rect = this.iconRects[i];
            if (rect == null || !rect.contains(mouseX, mouseY)) continue;
            return i;
        }
        return this.hoveredSector;
    }

    private int computeHoveredSector(double mouseX, double mouseY, float centerX, float centerY, float innerRadius, float outerRadius) {
        float dx = (float)mouseX - centerX;
        float dy = (float)mouseY - centerY;
        float distanceSq = dx * dx + dy * dy;
        float minRadius = Math.max(0.0f, innerRadius - 8.0f);
        float maxRadius = outerRadius + 8.0f + 4.0f + 8.0f;
        if (distanceSq < minRadius * minRadius || distanceSq > maxRadius * maxRadius) {
            return -1;
        }
        float angle = this.normalizeAngle((float)Math.toDegrees(Math.atan2(dy, dx)));
        for (int i = 0; i < 3; ++i) {
            float end;
            float center = this.normalizeAngle(this.getSectorCenterAngle(i));
            float start = this.normalizeAngle(center - 59.0f);
            if (!this.isAngleInside(angle, start, end = this.normalizeAngle(center + 59.0f))) continue;
            return i;
        }
        return -1;
    }

    private boolean isAngleInside(float angle, float startAngle, float endAngle) {
        if (startAngle <= endAngle) {
            return angle >= startAngle && angle <= endAngle;
        }
        return angle >= startAngle || angle <= endAngle;
    }

    private float getSectorCenterAngle(int index) {
        return -90.0f + (float)index * 120.0f;
    }

    private float normalizeAngle(float angle) {
        float normalized = angle % 360.0f;
        return normalized < 0.0f ? normalized + 360.0f : normalized;
    }

    private int lerpColor(int from, int to, float progress) {
        int a = class_3532.method_48781((float)progress, (int)(from >>> 24 & 0xFF), (int)(to >>> 24 & 0xFF));
        int r = class_3532.method_48781((float)progress, (int)(from >>> 16 & 0xFF), (int)(to >>> 16 & 0xFF));
        int g = class_3532.method_48781((float)progress, (int)(from >>> 8 & 0xFF), (int)(to >>> 8 & 0xFF));
        int b = class_3532.method_48781((float)progress, (int)(from & 0xFF), (int)(to & 0xFF));
        return a << 24 | r << 16 | g << 8 | b;
    }

    private record IconRect(int x, int y, int w, int h) {
        private boolean contains(double mouseX, double mouseY) {
            return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.w) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.h);
        }
    }
}

