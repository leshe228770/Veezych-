/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1661
 *  net.minecraft.class_1735
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2561
 *  net.minecraft.class_2815
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  net.minecraft.class_490
 *  net.minecraft.class_5134
 *  net.minecraft.class_7923
 *  net.minecraft.class_9285
 *  net.minecraft.class_9285$class_9287
 *  net.minecraft.class_9334
 */
package releon.ru.api.module.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2815;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.ClickSlotEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.module.impl.combat.autoswaputil.AutoSwapWheelScreen;
import releon.ru.api.settings.bind.KeyBind;
import releon.ru.api.settings.impl.BindSetting;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.api.settings.impl.StringSetting;
import releon.ru.utils.inventory.InventoryTask;
import releon.ru.utils.inventory.interaction.PlayerInteractionHelper;

public class AutoSwap
extends Module {
    private static AutoSwap instance;
    private final ModeSetting mode = this.register(new ModeSetting("Mode", "Swap mode.", "Double", "Double", "Triple"));
    private final ModeSetting firstItem = this.register(new ModeSetting("First Item", "First offhand item.", "Totem", "Totem", "Head", "GApple", "Shield"));
    private final ModeSetting secondItem = this.register(new ModeSetting("Second Item", "Second offhand item.", "Totem", "Totem", "Head", "GApple", "Shield"));
    private final BindSetting swapBind = this.register(new BindSetting("Swap Bind", "Uses AutoSwap without toggling the module.", KeyBind.NONE));
    private final BooleanSetting autoDamage = this.register(new BooleanSetting("Auto Damage", "Swaps to max-damage item by conditions.", false));
    private final MultiModeSetting autoDamageConditions = this.register(new MultiModeSetting("Conditions", "Auto damage conditions.", new String[]{"Target Low HP", "Target No Sword"}, "Target Low HP"));
    private final NumberSetting lowHpThreshold = this.register(new NumberSetting("HP Threshold", "Low target HP threshold.", 10.0, 1.0, 20.0, 1.0));
    private final StringSetting tripleSlotOneId = this.hiddenText("TripleSlotOneId");
    private final StringSetting tripleSlotOneName = this.hiddenText("TripleSlotOneName");
    private final StringSetting tripleSlotTwoId = this.hiddenText("TripleSlotTwoId");
    private final StringSetting tripleSlotTwoName = this.hiddenText("TripleSlotTwoName");
    private final StringSetting tripleSlotThreeId = this.hiddenText("TripleSlotThreeId");
    private final StringSetting tripleSlotThreeName = this.hiddenText("TripleSlotThreeName");
    private final WheelSlotItem[] wheelSlots = new WheelSlotItem[3];
    private Integer selectingSlotIndex;
    private class_1799 savedOffhandItem = class_1799.field_8037;
    private boolean autoDamageActive;
    private boolean swapBindWasDown;
    private class_2561 lastSwapDisplayName;
    private long lastSwapTimeMs;

    public AutoSwap() {
        super("AutoSwap", "Quickly swaps combat offhand items.", ModuleCategory.COMBAT);
        instance = this;
        this.autoDamageConditions.visibleWhen(this.autoDamage::getValue);
        this.lowHpThreshold.visibleWhen(() -> (Boolean)this.autoDamage.getValue() != false && this.autoDamageConditions.isSelected("Target Low HP"));
        this.syncWheelSlotsFromSettings();
    }

    public static AutoSwap getInstance() {
        return instance;
    }

    @Override
    public void onTick(class_310 client) {
        this.syncWheelSlotsFromSettings();
        if (client.field_1724 == null || client.field_1687 == null || client.method_22683() == null) {
            return;
        }
        boolean bindDown = ((KeyBind)this.swapBind.getValue()).isDown(client.method_22683().method_4490());
        if (client.field_1755 != null) {
            this.swapBindWasDown = bindDown;
            return;
        }
        if (bindDown && !this.swapBindWasDown) {
            this.useSwap();
        }
        this.swapBindWasDown = bindDown;
        if (((Boolean)this.autoDamage.getValue()).booleanValue()) {
            this.handleAutoDamage();
        }
    }

    @SubscribeEvent
    private void onClickSlot(ClickSlotEvent event) {
        class_1735 clickedSlot;
        class_310 mc = class_310.method_1551();
        if (this.selectingSlotIndex == null || !(mc.field_1755 instanceof class_490) || mc.field_1724 == null) {
            return;
        }
        class_1735 class_17352 = clickedSlot = event.getSlotId() >= 0 && event.getSlotId() < mc.field_1724.field_7512.field_7761.size() ? mc.field_1724.field_7512.method_7611(event.getSlotId()) : null;
        if (clickedSlot == null || !clickedSlot.method_7681() || clickedSlot.field_7871 != mc.field_1724.method_31548()) {
            return;
        }
        class_1799 stack = clickedSlot.method_7677();
        if (stack.method_7960()) {
            return;
        }
        this.setWheelSlotItem(this.selectingSlotIndex, stack.method_7909(), stack.method_7964().getString());
        this.selectingSlotIndex = null;
        event.cancel();
        mc.method_1507(null);
    }

    @Override
    protected void onDisable() {
        this.selectingSlotIndex = null;
        this.autoDamageActive = false;
        this.savedOffhandItem = class_1799.field_8037;
        this.lastSwapDisplayName = null;
        this.lastSwapTimeMs = 0L;
        this.swapBindWasDown = false;
    }

    private void useSwap() {
        class_1735 validSlot;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
            return;
        }
        if (this.mode.isSelected("Triple")) {
            if (this.hasConfiguredWheelSlot() && !this.hasAvailableWheelStack()) {
                return;
            }
            mc.method_1507((class_437)new AutoSwapWheelScreen(this));
            return;
        }
        class_1735 first = this.findConfiguredSlot(this.getItemByType((String)this.firstItem.getValue()));
        class_1735 second = this.findConfiguredSlot(this.getItemByType((String)this.secondItem.getValue()));
        class_1735 class_17352 = validSlot = first != null && mc.field_1724.method_6079().method_7909() != first.method_7677().method_7909() ? first : second;
        if (validSlot != null) {
            this.swapToSlot(validSlot);
        }
    }

    private void handleAutoDamage() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
            return;
        }
        class_1309 target = AuraModule.target;
        boolean shouldSwapToDamage = false;
        if (target != null && target.method_5805()) {
            class_1657 player;
            boolean lowHpCondition = this.autoDamageConditions.isSelected("Target Low HP") && target.method_6032() <= this.lowHpThreshold.getFloat() && target.method_6032() < mc.field_1724.method_6032();
            boolean noSwordCondition = this.autoDamageConditions.isSelected("Target No Sword") && target instanceof class_1657 && this.getAttackDamage((player = (class_1657)target).method_6047()) <= 0.0;
            boolean bl = shouldSwapToDamage = ((Set)this.autoDamageConditions.getValue()).isEmpty() || lowHpCondition || noSwordCondition;
        }
        if (shouldSwapToDamage && !this.autoDamageActive) {
            this.savedOffhandItem = mc.field_1724.method_6079().method_7972();
            class_1799 bestDamageItem = this.findBestDamageItem();
            if (!bestDamageItem.method_7960()) {
                this.swapToItemStack(bestDamageItem);
                this.autoDamageActive = true;
            }
            return;
        }
        if (!shouldSwapToDamage && this.autoDamageActive) {
            if (!this.savedOffhandItem.method_7960()) {
                this.swapToItemStack(this.savedOffhandItem);
            }
            this.autoDamageActive = false;
            this.savedOffhandItem = class_1799.field_8037;
        }
    }

    private class_1799 findBestDamageItem() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return class_1799.field_8037;
        }
        ArrayList<class_1799> damageItems = new ArrayList<class_1799>();
        class_1661 inventory = mc.field_1724.method_31548();
        for (int i = 0; i < inventory.method_5439(); ++i) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || stack.method_7909() != class_1802.field_8575 && stack.method_7909() != class_1802.field_8288 || !(this.getAttackDamage(stack) > 0.0)) continue;
            damageItems.add(stack);
        }
        return damageItems.stream().max(Comparator.comparingDouble(this::getAttackDamage)).orElse(class_1799.field_8037);
    }

    private double getAttackDamage(class_1799 stack) {
        class_9285 modifiers = (class_9285)stack.method_58694(class_9334.field_49636);
        if (modifiers == null) {
            return 0.0;
        }
        double totalDamage = 0.0;
        for (class_9285.class_9287 entry : modifiers.comp_2393()) {
            if (entry.comp_2395().comp_349() != class_5134.field_23721.comp_349()) continue;
            totalDamage += entry.comp_2396().comp_2449();
        }
        return totalDamage;
    }

    private void swapToItemStack(class_1799 targetStack) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null) {
            return;
        }
        if (targetStack == null || targetStack.method_7960()) {
            return;
        }
        class_1735 foundSlot = this.findSlotByStack(targetStack);
        if (foundSlot != null) {
            this.swapToSlot(foundSlot);
        }
    }

    private void swapToSlot(class_1735 slot) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null || mc.field_1724 == null || slot == null || !slot.method_7681() || !this.isValidInventorySlot(slot)) {
            return;
        }
        class_1799 swappedTo = slot.method_7677().method_7972();
        mc.field_1724.method_5728(false);
        InventoryTask.swapHand(slot, class_1268.field_5810, true, true);
        this.triggerSwapToast(swappedTo);
    }

    private class_1735 findSlotByStack(class_1799 targetStack) {
        return InventoryTask.slots().filter(this::isValidInventorySlot).filter(slot -> slot.method_7677().method_7909() == targetStack.method_7909()).filter(slot -> slot.method_7677().method_7964().getString().equals(targetStack.method_7964().getString())).findFirst().or(() -> InventoryTask.slots().filter(this::isValidInventorySlot).filter(slot -> slot.method_7677().method_7909() == targetStack.method_7909()).findFirst()).orElse(null);
    }

    private class_1735 findConfiguredSlot(class_1792 item) {
        return InventoryTask.getSlot(item, Comparator.comparing(slot -> slot.method_7677().method_7958()), this::isValidInventorySlot);
    }

    private boolean isValidInventorySlot(class_1735 slot) {
        int slotId = InventoryTask.getMenuSlotId(slot);
        return slotId != 45 && slotId != 46;
    }

    private void triggerSwapToast(class_1799 swappedTo) {
        if (swappedTo == null || swappedTo.method_7960()) {
            return;
        }
        this.lastSwapTimeMs = System.currentTimeMillis();
        this.lastSwapDisplayName = swappedTo.method_7964();
    }

    public class_1792 getItemByType(String itemType) {
        return switch (itemType) {
            case "Totem" -> class_1802.field_8288;
            case "Head" -> class_1802.field_8575;
            case "GApple" -> class_1802.field_8463;
            case "Shield" -> class_1802.field_8255;
            default -> class_1802.field_8162;
        };
    }

    public void setWheelSlotItem(int index, class_1792 item, String itemName) {
        if (index < 0 || index >= this.wheelSlots.length) {
            return;
        }
        if (item == null || item == class_1802.field_8162) {
            this.wheelSlots[index] = null;
            this.updateWheelSlotSettings(index, "", "");
            return;
        }
        String normalizedName = itemName == null ? "" : itemName;
        this.wheelSlots[index] = new WheelSlotItem(item, normalizedName);
        this.updateWheelSlotSettings(index, class_7923.field_41178.method_10221((Object)item).toString(), normalizedName);
    }

    public void startSelectingItem(int wheelSlotIndex) {
        class_310 mc = class_310.method_1551();
        this.selectingSlotIndex = wheelSlotIndex;
        if (mc.field_1724 != null) {
            this.closeCurrentContainerBeforeInventory(mc);
            mc.method_1507((class_437)new class_490((class_1657)mc.field_1724));
        }
    }

    private void closeCurrentContainerBeforeInventory(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1724.field_7512 == mc.field_1724.field_7498) {
            return;
        }
        if (mc.method_1562() != null) {
            PlayerInteractionHelper.sendPacketWithOutEvent(new class_2815(mc.field_1724.field_7512.field_7763));
        }
        mc.field_1724.field_7512 = mc.field_1724.field_7498;
    }

    public class_1799 getWheelSlotStack(int index) {
        this.syncWheelSlotsFromSettings();
        if (index < 0 || index >= this.wheelSlots.length) {
            return class_1799.field_8037;
        }
        WheelSlotItem slotItem = this.wheelSlots[index];
        if (slotItem == null || slotItem.item() == null || slotItem.item() == class_1802.field_8162) {
            return class_1799.field_8037;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return class_1799.field_8037;
        }
        class_1661 inventory = mc.field_1724.method_31548();
        class_1799 sameItemFallback = class_1799.field_8037;
        for (int i = 0; i < inventory.method_5439(); ++i) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || stack.method_7909() != slotItem.item()) continue;
            if (stack.method_7964().getString().equals(slotItem.itemName())) {
                return stack;
            }
            if (!sameItemFallback.method_7960()) continue;
            sameItemFallback = stack;
        }
        return sameItemFallback;
    }

    public void startSwapToItemStack(class_1799 stack) {
        this.swapToItemStack(stack);
    }

    private boolean hasConfiguredWheelSlot() {
        this.syncWheelSlotsFromSettings();
        for (WheelSlotItem slotItem : this.wheelSlots) {
            if (slotItem == null || slotItem.item() == null || slotItem.item() == class_1802.field_8162) continue;
            return true;
        }
        return false;
    }

    private boolean hasAvailableWheelStack() {
        for (int i = 0; i < this.wheelSlots.length; ++i) {
            if (this.getWheelSlotStack(i).method_7960()) continue;
            return true;
        }
        return false;
    }

    private void syncWheelSlotsFromSettings() {
        this.syncWheelSlot(0, this.tripleSlotOneId, this.tripleSlotOneName);
        this.syncWheelSlot(1, this.tripleSlotTwoId, this.tripleSlotTwoName);
        this.syncWheelSlot(2, this.tripleSlotThreeId, this.tripleSlotThreeName);
    }

    private void syncWheelSlot(int index, StringSetting idSetting, StringSetting nameSetting) {
        String itemId = this.normalizeSettingText(idSetting);
        String itemName = this.normalizeSettingText(nameSetting);
        if (itemId.isEmpty()) {
            this.wheelSlots[index] = null;
            return;
        }
        class_2960 identifier = class_2960.method_12829((String)itemId);
        if (identifier == null || !class_7923.field_41178.method_10250(identifier)) {
            this.wheelSlots[index] = null;
            return;
        }
        class_1792 item = (class_1792)class_7923.field_41178.method_63535(identifier);
        WheelSlotItem current = this.wheelSlots[index];
        if (current == null || current.item() != item || !current.itemName().equals(itemName)) {
            this.wheelSlots[index] = new WheelSlotItem(item, itemName);
        }
    }

    private void updateWheelSlotSettings(int index, String itemId, String itemName) {
        this.wheelSlotIdSetting(index).setValue(itemId);
        this.wheelSlotNameSetting(index).setValue(itemName);
    }

    private StringSetting wheelSlotIdSetting(int index) {
        return switch (index) {
            case 0 -> this.tripleSlotOneId;
            case 1 -> this.tripleSlotTwoId;
            case 2 -> this.tripleSlotThreeId;
            default -> throw new IllegalArgumentException("Invalid wheel slot index: " + index);
        };
    }

    private StringSetting wheelSlotNameSetting(int index) {
        return switch (index) {
            case 0 -> this.tripleSlotOneName;
            case 1 -> this.tripleSlotTwoName;
            case 2 -> this.tripleSlotThreeName;
            default -> throw new IllegalArgumentException("Invalid wheel slot index: " + index);
        };
    }

    private String normalizeSettingText(StringSetting setting) {
        return setting.getValue() == null ? "" : ((String)setting.getValue()).trim();
    }

    private StringSetting hiddenText(String name) {
        StringSetting setting = new StringSetting(name, "", "", 256);
        setting.visibleWhen(() -> false);
        return this.register(setting);
    }

    private record WheelSlotItem(class_1792 item, String itemName) {
    }
}

