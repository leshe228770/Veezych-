/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 */
package releon.ru.utils.inventory.lookup;

import net.minecraft.class_1799;

@FunctionalInterface
public interface ItemSearcher {
    public boolean matches(class_1799 var1);
}

