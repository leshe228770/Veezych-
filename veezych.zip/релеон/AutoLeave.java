/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 */
package releon.ru.api.module.impl.misc;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.network.Network;
import releon.ru.utils.repository.friend.FriendUtils;

public final class AutoLeave
extends Module {
    private final ModeSetting leaveType = this.register(new ModeSetting("Leave Type", "Leave action.", "Disconnect", "Hub", "Disconnect"));
    private final MultiModeSetting triggers = this.register(new MultiModeSetting("Triggers", "Auto leave triggers.", new String[]{"Players", "Staff", "HP"}, "Players", "Staff"));
    private final NumberSetting distance = this.register(new NumberSetting("Max Distance", "Player trigger distance.", 10.0, 5.0, 40.0, 1.0));
    private final NumberSetting hp = this.register(new NumberSetting("Minimum HP", "Health trigger threshold.", 8.0, 1.0, 40.0, 1.0));

    public AutoLeave() {
        super("Auto Leave", "Leaves the server when selected danger triggers fire.", ModuleCategory.MISC);
        this.distance.visibleWhen(() -> this.triggers.isSelected("Players"));
        this.hp.visibleWhen(() -> this.triggers.isSelected("HP"));
    }

    @SubscribeEvent
    private void onTick(TickEvent event) {
        float health;
        if (AutoLeave.mc.field_1724 == null || AutoLeave.mc.field_1687 == null || mc.method_1562() == null) {
            return;
        }
        if (this.triggers.isSelected("HP") && (health = Network.getResolvedHealth((class_1309)AutoLeave.mc.field_1724, true)) > 0.0f && health <= this.hp.getFloat()) {
            this.leave((class_2561)class_2561.method_43470((String)(" - HP dropped to " + Network.formatHealthValue(health))));
            return;
        }
        if (Network.isPvp()) {
            return;
        }
        if (this.triggers.isSelected("Players")) {
            for (class_1657 player : AutoLeave.mc.field_1687.method_18456()) {
                if (player == AutoLeave.mc.field_1724 || FriendUtils.isFriend((class_1297)player) || AutoLeave.mc.field_1724.method_5739((class_1297)player) >= this.distance.getFloat()) continue;
                this.leave((class_2561)player.method_5477().method_27661().method_27693(" - appeared nearby " + Math.round(AutoLeave.mc.field_1724.method_5739((class_1297)player)) + "m"));
                return;
            }
        }
    }

    private void leave(class_2561 text) {
        if (mc.method_1562() == null) {
            return;
        }
        if (this.leaveType.is("Hub")) {
            mc.method_1562().method_45730("hub");
        } else {
            mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_30163((String)"[Auto Leave]\n").method_27661().method_10852(text));
        }
        this.setEnabled(false);
    }
}

