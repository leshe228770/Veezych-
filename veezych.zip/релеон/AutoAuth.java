/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_7439
 */
package releon.ru.api.module.impl.misc;

import java.util.Locale;
import net.minecraft.class_2596;
import net.minecraft.class_7439;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.StringSetting;

public final class AutoAuth
extends Module {
    private final StringSetting password = this.register(new StringSetting("Password", "Server auth password.", "ReleonPass123", 64));

    public AutoAuth() {
        super("Auto Auth", "Automatically sends /login and /register commands.", ModuleCategory.MISC);
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        String pass;
        if (!event.isReceive() || AutoAuth.mc.field_1724 == null || AutoAuth.mc.field_1687 == null || AutoAuth.mc.field_1724.field_3944 == null) {
            return;
        }
        class_2596<?> class_25962 = event.getPacket();
        if (!(class_25962 instanceof class_7439)) {
            return;
        }
        class_7439 packet = (class_7439)class_25962;
        String string = pass = this.password.getValue() == null ? "" : ((String)this.password.getValue()).trim();
        if (pass.length() < 4) {
            return;
        }
        String message = packet.comp_763().getString().toLowerCase(Locale.ROOT);
        if (message.contains("\u0432\u043e\u0439\u0434\u0438\u0442\u0435") || message.contains("/login")) {
            AutoAuth.mc.field_1724.field_3944.method_45730("login " + pass);
            return;
        }
        if (message.contains("\u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435\u0441\u044c") || message.contains("\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f") || message.contains("/reg")) {
            AutoAuth.mc.field_1724.field_3944.method_45730("reg " + pass + " " + pass);
        }
    }
}

