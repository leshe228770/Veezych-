/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1542
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 */
package releon.ru.api.module.impl.visual.esp;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import releon.ru.api.module.impl.visual.esp.EspColors;
import releon.ru.api.module.impl.visual.esp.EspGeometry;
import releon.ru.api.module.impl.visual.esp.EspHealthTracker;
import releon.ru.api.module.impl.visual.esp.EspVisualRenderer;
import releon.ru.api.module.impl.visual.esp.PlayerTagResolver;
import releon.ru.api.module.impl.visual.esp.TagPart;
import releon.ru.api.module.impl.visual.esp.TagParts;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.ui.font.FontType;
import releon.ru.utils.repository.friend.FriendUtils;

public final class EspTagRenderer {
    private final PlayerTagResolver playerTags;
    private final EspHealthTracker healthTracker;
    private final List<TagPart> parts = new ArrayList<TagPart>(12);

    public EspTagRenderer(PlayerTagResolver playerTags, EspHealthTracker healthTracker) {
        this.playerTags = playerTags;
        this.healthTracker = healthTracker;
    }

    /*
     * Unable to fully structure code
     */
    public void drawTag(class_1297 entity, EspGeometry.ScreenBox box, EspGeometry.ScreenAnchor anchor, boolean includeHealth, float alpha, MultiModeSetting tagElements, class_310 mc, class_332 graphics) {
        this.parts.clear();
        iconStack = class_1799.field_8037;
        roundIcon = false;
        if (entity instanceof class_1542) {
            item = (class_1542)entity;
            iconStack = stack = item.method_6983();
            TagParts.addTagPart(this.parts, FontType.SEMIBOLD, TagParts.clean(stack.method_7964().getString()), EspColors.TAG_TEXT, 0.0f);
            if (stack.method_7947() > 1) {
                TagParts.addTagPart(this.parts, FontType.SEMIBOLD, " x" + stack.method_7947(), EspColors.TAG_MUTED, 0.0f);
            }
        } else if (entity instanceof class_1657) {
            player = (class_1657)entity;
            tag = this.playerTags.resolve(player, mc);
            if (tagElements.isSelected("Friend Prefix") && FriendUtils.isFriend((class_1297)player)) {
                TagParts.addTagPart(this.parts, FontType.SEMIBOLD, "(F)", ColorUtil.rgba(42, 255, 118, 255), -0.25f);
            }
            TagParts.addTagParts(this.parts, TagParts.withYOffset(tag.voice(), 0.0f));
            if (tagElements.isSelected("Donation")) {
                TagParts.addTagParts(this.parts, TagParts.withYOffset(TagParts.compactToSingleTextPart(tag.donation(), FontType.BOLD, EspColors.TAG_MUTED), -0.5f));
            }
            if (tagElements.isSelected("Prefix")) {
                TagParts.addTagParts(this.parts, TagParts.withYOffset(TagParts.compactToSingleTextPart(tag.prefix(), FontType.SEMIBOLD, EspColors.TAG_MUTED), 0.0f));
            }
            TagParts.addTagParts(this.parts, TagParts.withYOffset(tag.name(), 0.0f));
            if (tagElements.isSelected("Suffix")) {
                TagParts.addTagParts(this.parts, TagParts.withYOffset(tag.suffix(), 0.0f));
            }
            if (includeHealth && tagElements.isSelected("Health")) {
                TagParts.addTagPart(this.parts, FontType.BOLD, this.healthTracker.formatHealth(this.healthTracker.resolveDisplayHealth((class_1309)player)), EspVisualRenderer.healthTextColor((class_1309)player, this.healthTracker), 0.0f);
            }
        } else {
            TagParts.addTagPart(this.parts, FontType.SEMIBOLD, this.labelFor(entity, false), EspColors.TAG_TEXT, 0.0f);
        }
        if (includeHealth && entity instanceof class_1309) {
            living = (class_1309)entity;
            if (!(entity instanceof class_1657)) {
                TagParts.addTagPart(this.parts, FontType.SEMIBOLD, " [" + this.healthTracker.formatHealth(this.healthTracker.resolveDisplayHealth(living)) + "HP]", EspColors.TAG_HEALTH, 0.0f);
            }
        }
        if (this.parts.isEmpty() && iconStack.method_7960()) {
            return;
        }
        if (!(entity instanceof class_1657)) ** GOTO lbl-1000
        player = (class_1657)entity;
        if (tagElements.isSelected("Head")) {
            v0 = player;
        } else lbl-1000:
        // 2 sources

        {
            v0 = null;
        }
        headPlayer = v0;
        EspVisualRenderer.drawTagFrame(headPlayer, this.parts, iconStack, roundIcon, box, anchor, alpha, graphics);
    }

    public void drawHealthBar(EspGeometry.ScreenBox box, class_1309 entity, float alpha) {
        EspVisualRenderer.drawHealthBar(box, entity, alpha, this.healthTracker);
    }

    public void drawEquipment(class_1657 player, EspGeometry.ScreenBox box, EspGeometry.ScreenAnchor anchor, float alpha) {
        EspVisualRenderer.drawEquipment(player, box, anchor, alpha);
    }

    public void drawPotions(class_1309 entity, EspGeometry.ScreenBox box, float alpha) {
        EspVisualRenderer.drawPotions(entity, box, alpha);
    }

    private String labelFor(class_1297 entity, boolean includeHealth) {
        class_1657 player;
        if (entity instanceof class_1542) {
            class_1542 item = (class_1542)entity;
            class_1799 stack = item.method_6983();
            String name = TagParts.clean(stack.method_7964().getString());
            return stack.method_7947() > 1 ? name + " x" + stack.method_7947() : name;
        }
        Object name = TagParts.clean(entity.method_5477().getString());
        if (entity instanceof class_1657 && FriendUtils.isFriend((class_1297)(player = (class_1657)entity))) {
            name = "Friend " + (String)name;
        }
        if (includeHealth && entity instanceof class_1309) {
            class_1309 living = (class_1309)entity;
            name = (String)name + " [" + this.healthTracker.formatHealth(this.healthTracker.resolveDisplayHealth(living)) + "HP]";
        }
        return name;
    }
}

