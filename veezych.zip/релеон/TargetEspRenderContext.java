/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 */
package releon.ru.utils.render.world.targetesp;

import net.minecraft.class_1309;

public record TargetEspRenderContext(class_1309 target, float alpha, float partialTicks, long frameTimeMs, int primaryColor, int secondaryColor, float hurtProgress, float chainImpactProgress) {
}

