/*
 * Decompiled with CFR 0.152.
 */
package releon.ru.api.module.impl.visual.esp;

import releon.ru.utils.render.color.ColorUtil;

public final class EspColors {
    public static final int TAG_TEXT = ColorUtil.rgba(255, 255, 255, 245);
    public static final int TAG_MUTED = ColorUtil.rgba(165, 165, 165, 245);
    public static final int TAG_HEALTH = ColorUtil.rgba(255, 80, 80, 255);
    public static final int ITEM = ColorUtil.rgba(255, 210, 92, 210);

    private EspColors() {
    }
}

