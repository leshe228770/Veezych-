/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 *  net.minecraft.class_266
 *  net.minecraft.class_269
 *  net.minecraft.class_8646
 *  net.minecraft.class_9013
 *  net.minecraft.class_9015
 */
package releon.ru.api.module.impl.visual.esp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_8646;
import net.minecraft.class_9013;
import net.minecraft.class_9015;

public final class EspHealthTracker {
    private static final long SERVER_HEALTH_TIMEOUT_MS = 3000L;
    private static final Pattern HEALTH_NUMBER_PATTERN = Pattern.compile("\\d+(?:[.,]\\d+)?");
    private final Map<UUID, ServerHealth> serverHealthByPlayer = new HashMap<UUID, ServerHealth>();

    public void clear() {
        this.serverHealthByPlayer.clear();
    }

    public void prune() {
        long now = System.currentTimeMillis();
        this.serverHealthByPlayer.entrySet().removeIf(entry -> now - ((ServerHealth)entry.getValue()).timestampMs() > 3000L);
    }

    public void capture(class_1297 entity, class_2561 scoreText) {
        if (!(entity instanceof class_1657)) {
            return;
        }
        class_1657 player = (class_1657)entity;
        if (scoreText == null) {
            this.serverHealthByPlayer.remove(player.method_5667());
            return;
        }
        Float health = this.parseServerHealth(scoreText.getString());
        if (health != null) {
            this.serverHealthByPlayer.put(player.method_5667(), new ServerHealth(health.floatValue(), System.currentTimeMillis()));
        }
    }

    public float resolveDisplayHealth(class_1309 entity) {
        return this.resolveDisplayHealth(entity, true);
    }

    public float resolveDisplayHealth(class_1309 entity, boolean includeAbsorption) {
        class_1657 player;
        Float trackedHealth;
        if (entity instanceof class_1657 && (trackedHealth = this.resolveTrackedHealth(player = (class_1657)entity)) != null) {
            return trackedHealth.floatValue();
        }
        float health = Math.max(0.0f, entity.method_6032());
        return includeAbsorption ? health + Math.max(0.0f, entity.method_6067()) : health;
    }

    public String formatHealth(float health) {
        int scaled = Math.max(0, Math.round(health * 10.0f));
        int whole = scaled / 10;
        int fraction = scaled % 10;
        if (fraction == 0) {
            return Integer.toString(whole);
        }
        return whole + "." + fraction;
    }

    private Float parseServerHealth(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        Matcher matcher = HEALTH_NUMBER_PATTERN.matcher(text);
        if (!matcher.find()) {
            return null;
        }
        try {
            float value = Float.parseFloat(matcher.group().replace(',', '.'));
            return Float.isFinite(value) && value >= 0.0f ? Float.valueOf(value) : null;
        }
        catch (NumberFormatException ignored) {
            return null;
        }
    }

    private Float resolveScoreboardHealth(class_1657 player) {
        try {
            if (player.method_73183() == null) {
                return null;
            }
            class_269 scoreboard = player.method_73183().method_8428();
            class_266 objective = scoreboard.method_1189(class_8646.field_45158);
            if (objective == null) {
                return null;
            }
            class_9013 score = scoreboard.method_55430((class_9015)player, objective);
            if (score == null) {
                return null;
            }
            float health = score.method_55397();
            return this.isValidServerHealth(player, health) ? Float.valueOf(health) : null;
        }
        catch (Exception ignored) {
            return null;
        }
    }

    private Float resolveTrackedHealth(class_1657 player) {
        Float scoreboardHealth = this.resolveScoreboardHealth(player);
        if (scoreboardHealth != null) {
            return scoreboardHealth;
        }
        ServerHealth serverHealth = this.serverHealthByPlayer.get(player.method_5667());
        if (serverHealth != null && System.currentTimeMillis() - serverHealth.timestampMs() <= 3000L) {
            return Float.valueOf(Math.max(0.0f, serverHealth.health()));
        }
        return null;
    }

    private boolean isValidServerHealth(class_1657 player, float health) {
        if (!Float.isFinite(health) || health < 0.0f || health > 500.0f) {
            return false;
        }
        float maxHealth = Math.max(1.0f, player.method_6063() + player.method_6067());
        return health <= Math.max(maxHealth * 8.0f, 200.0f);
    }

    private record ServerHealth(float health, long timestampMs) {
    }
}

