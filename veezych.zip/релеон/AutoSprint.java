/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  net.minecraft.class_304
 *  net.minecraft.class_310
 *  net.minecraft.class_3675
 *  net.minecraft.class_3675$class_306
 *  net.minecraft.class_3675$class_307
 *  org.lwjgl.glfw.GLFW
 */
package releon.ru.api.module.impl.movement;

import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.screens.clickgui.ClickGui;

public final class AutoSprint
extends Module {
    public AutoSprint() {
        super("Auto Sprint", "Keeps sprint enabled while moving.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1690 == null || client.method_22683() == null) {
            return;
        }
        if (client.field_1755 != null) {
            boolean movingInClickGui = client.field_1755 instanceof ClickGui && (this.isPressed(client, client.field_1690.field_1894) || this.isPressed(client, client.field_1690.field_1881) || this.isPressed(client, client.field_1690.field_1913) || this.isPressed(client, client.field_1690.field_1849));
            client.field_1690.field_1867.method_23481(movingInClickGui);
            if (client.field_1724.method_5624() != movingInClickGui) {
                client.field_1724.method_5728(movingInClickGui);
            }
            return;
        }
        boolean moving = this.isPressed(client, client.field_1690.field_1894) || this.isPressed(client, client.field_1690.field_1881) || this.isPressed(client, client.field_1690.field_1913) || this.isPressed(client, client.field_1690.field_1849);
        client.field_1690.field_1867.method_23481(moving);
        if (!moving && client.field_1755 != null && client.field_1724.method_5624()) {
            client.field_1724.method_5728(false);
        }
    }

    private boolean isPressed(class_310 client, class_304 key) {
        class_3675.class_306 inputKey = class_3675.method_15981((String)key.method_1428());
        long handle = client.method_22683().method_4490();
        return switch (inputKey.method_1442()) {
            case class_3675.class_307.field_1668 -> class_3675.method_15987((class_1041)client.method_22683(), (int)inputKey.method_1444());
            case class_3675.class_307.field_1672 -> {
                if (GLFW.glfwGetMouseButton((long)handle, (int)inputKey.method_1444()) == 1) {
                    yield true;
                }
                yield false;
            }
            default -> false;
        };
    }
}

