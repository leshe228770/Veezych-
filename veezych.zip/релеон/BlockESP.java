/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1922
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2338$class_2339
 *  net.minecraft.class_238
 *  net.minecraft.class_2561
 *  net.minecraft.class_259
 *  net.minecraft.class_265
 *  net.minecraft.class_2680
 *  net.minecraft.class_2818
 *  net.minecraft.class_2902$class_2903
 *  net.minecraft.class_310
 *  net.minecraft.class_7923
 */
package releon.ru.api.module.impl.visual;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.repository.blockesp.BlockESPConfig;
import releon.ru.utils.string.chat.ChatMessage;

public final class BlockESP
extends Module {
    private static BlockESP instance;
    private final ColorSetting color = this.register(new ColorSetting("Color", "Block highlight color.", new Color(127, 242, 255, 136)));
    private final NumberSetting range = this.register(new NumberSetting("Range", "Search radius for blocks.", 32.0, 1.0, 128.0, 1.0));
    private final BooleanSetting notifyInChat = this.register(new BooleanSetting("Notify", "Show found blocks in chat.", false));
    private final Set<String> blocksToHighlight = new CopyOnWriteArraySet<String>();
    private final Map<class_2338, class_2680> renderBlocks = new HashMap<class_2338, class_2680>();
    private final Set<class_2338> notifiedBlocks = new CopyOnWriteArraySet<class_2338>();
    private long lastScanTime;
    private int checkCounter;

    public BlockESP() {
        super("Block ESP", "Highlights selected blocks in the world.", ModuleCategory.VISUAL);
        instance = this;
    }

    public static BlockESP getInstance() {
        return instance;
    }

    public Set<String> getBlocksToHighlight() {
        return this.blocksToHighlight;
    }

    @Override
    protected void onEnable() {
        this.blocksToHighlight.clear();
        this.blocksToHighlight.addAll(BlockESPConfig.getInstance().getBlocks());
        this.renderBlocks.clear();
        this.notifiedBlocks.clear();
        this.lastScanTime = 0L;
        this.checkCounter = 0;
    }

    @Override
    protected void onDisable() {
        this.renderBlocks.clear();
        this.notifiedBlocks.clear();
    }

    @Override
    public void onTick(class_310 client) {
        if (client == null || client.field_1687 == null || client.field_1724 == null) {
            this.renderBlocks.clear();
            return;
        }
        if (this.blocksToHighlight.isEmpty()) {
            this.renderBlocks.clear();
            return;
        }
        class_2338 playerPos = client.field_1724.method_24515();
        long currentTime = System.nanoTime() / 1000000L;
        if (currentTime - this.lastScanTime >= 2000L) {
            this.scanChunkArea(playerPos, 2, 48, true);
            this.lastScanTime = currentTime;
            this.checkCounter = 0;
        }
        if (this.checkCounter % 5 == 0) {
            this.scanChunkArea(playerPos, 1, 24, false);
        }
        if (this.checkCounter % 60 == 0) {
            this.renderBlocks.entrySet().removeIf(entry -> {
                boolean shouldRemove;
                class_2338 pos = (class_2338)entry.getKey();
                class_2248 block = client.field_1687.method_8320(pos).method_26204();
                String blockName = class_7923.field_41175.method_10221((Object)block).toString();
                boolean bl = shouldRemove = !this.blocksToHighlight.contains(blockName);
                if (shouldRemove) {
                    this.notifiedBlocks.remove(pos);
                }
                return shouldRemove;
            });
        }
        ++this.checkCounter;
    }

    @SubscribeEvent
    private void onRender3D(WorldRenderEvent event) {
        if (!this.isEnabled() || BlockESP.mc.field_1687 == null || BlockESP.mc.field_1724 == null) {
            this.renderBlocks.clear();
            return;
        }
        if (this.blocksToHighlight.isEmpty()) {
            this.renderBlocks.clear();
            return;
        }
        this.renderHighlightedBlocks(((Color)this.color.getValue()).getRGB());
    }

    private void renderHighlightedBlocks(int highlightColor) {
        for (Map.Entry<class_2338, class_2680> entry : this.renderBlocks.entrySet()) {
            class_238 box;
            class_2338 pos = entry.getKey();
            class_2680 state = entry.getValue();
            class_265 shape = state.method_26218((class_1922)BlockESP.mc.field_1687, pos);
            if (shape.method_1110()) {
                shape = state.method_26220((class_1922)BlockESP.mc.field_1687, pos);
            }
            if (shape.method_1110()) {
                box = new class_238(pos);
                Render3D.drawBox(box, highlightColor, 1.0f);
                Render3D.drawBoxOverlay(box, highlightColor, 1.25f);
                continue;
            }
            if (shape == class_259.method_1077()) {
                box = new class_238(pos);
                Render3D.drawBox(box, highlightColor, 1.0f);
                Render3D.drawBoxOverlay(box, highlightColor, 1.25f);
                continue;
            }
            Render3D.drawShapeAlternative(pos, shape, highlightColor, 1.0f, true, false);
            Render3D.drawShapeOverlay(pos, shape, highlightColor, 1.25f);
        }
    }

    private void scanChunkArea(class_2338 playerPos, int chunkRange, int yRange, boolean fullRefresh) {
        if (BlockESP.mc.field_1687 == null || BlockESP.mc.field_1724 == null) {
            return;
        }
        if (fullRefresh) {
            this.renderBlocks.clear();
        }
        double maxDistanceSqr = (double)this.range.getFloat() * (double)this.range.getFloat();
        int minYBase = BlockESP.mc.field_1687.method_31607();
        class_2338.class_2339 mutablePos = new class_2338.class_2339();
        for (int x = -chunkRange; x <= chunkRange; ++x) {
            for (int z = -chunkRange; z <= chunkRange; ++z) {
                class_2818 chunk;
                int chunkX = (playerPos.method_10263() >> 4) + x;
                int chunkZ = (playerPos.method_10260() >> 4) + z;
                if (!BlockESP.mc.field_1687.method_2935().method_12123(chunkX, chunkZ) || (chunk = BlockESP.mc.field_1687.method_2935().method_21730(chunkX, chunkZ)) == null) continue;
                int cx = chunk.method_12004().field_9181 << 4;
                int cz = chunk.method_12004().field_9180 << 4;
                for (int bx = 0; bx < 16; ++bx) {
                    for (int bz = 0; bz < 16; ++bz) {
                        int columnX = cx + bx;
                        int columnZ = cz + bz;
                        int minY = Math.max(minYBase, playerPos.method_10264() - yRange);
                        int maxY = Math.min(BlockESP.mc.field_1687.method_8624(class_2902.class_2903.field_13202, columnX, columnZ), playerPos.method_10264() + yRange);
                        for (int by = minY; by <= maxY; ++by) {
                            class_2680 state;
                            String blockName;
                            mutablePos.method_10103(columnX, by, columnZ);
                            double dist = BlockESP.mc.field_1724.method_5649((double)columnX + 0.5, (double)by + 0.5, (double)columnZ + 0.5);
                            if (dist > maxDistanceSqr || !this.blocksToHighlight.contains(blockName = class_7923.field_41175.method_10221((Object)(state = BlockESP.mc.field_1687.method_8320((class_2338)mutablePos)).method_26204()).toString()) || this.renderBlocks.containsKey(mutablePos)) continue;
                            class_2338 immutablePos = mutablePos.method_10062();
                            this.renderBlocks.put(immutablePos, state);
                            if (!((Boolean)this.notifyInChat.getValue()).booleanValue() || this.notifiedBlocks.contains(mutablePos)) continue;
                            this.notifyBlockFound(immutablePos, blockName);
                            this.notifiedBlocks.add(immutablePos);
                        }
                    }
                }
            }
        }
    }

    private void notifyBlockFound(class_2338 pos, String blockName) {
        if (BlockESP.mc.field_1724 == null) {
            return;
        }
        BlockESP.mc.field_1724.method_7353((class_2561)ChatMessage.blockesp().method_27661().method_10852((class_2561)class_2561.method_43470((String)(" -> " + blockName + " @ " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()))), false);
    }
}

