/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1735
 *  net.minecraft.class_1747
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2480
 *  net.minecraft.class_310
 */
package releon.ru.api.module.impl.player;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2480;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.aura.util.StopWatch;
import releon.ru.api.settings.impl.BooleanSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.api.settings.impl.MultiModeSetting;
import releon.ru.api.settings.impl.NumberSetting;
import releon.ru.utils.inventory.InventoryTask;

public final class ChestStealer
extends Module {
    private static final int STOP_BEFORE_LOOT_TICKS = 2;
    private static final String[] LOOT_ITEMS = new String[]{"Totem", "Netherite Helmet", "Netherite Chestplate", "Netherite Leggings", "Netherite Boots", "Netherite Sword", "Netherite Pickaxe", "Enchanted Golden Apple", "Player Head", "Shulker Box", "Netherite Ingot", "Dragon Head", "Elytra", "Snowball", "Splash Potion", "Tripwire Hook", "Netherite Scrap", "Beacon", "Villager Spawn Egg"};
    private final StopWatch lootWatch = new StopWatch();
    private final Map<class_1792, String> itemNames = new HashMap<class_1792, String>();
    private final ModeSetting mode = this.register(new ModeSetting("Mode", "Chest looting mode.", "Default", "Default", "FT Warden"));
    private final NumberSetting delay = this.register(new NumberSetting("Delay", "Delay between slots.", 100.0, 0.0, 1000.0, 10.0));
    private final BooleanSetting whitelistEnabled = this.register(new BooleanSetting("Whitelist", "Loot only selected items.", false));
    private final MultiModeSetting defaultWhitelist = this.register(new MultiModeSetting("Default Loot", "Selected Default loot.", LOOT_ITEMS, new String[0]));
    private final MultiModeSetting ftWardenWhitelist = this.register(new MultiModeSetting("FT Warden Loot", "Selected FT Warden loot.", LOOT_ITEMS, new String[0]));
    private boolean chestSessionActive;
    private int stopTicksRemaining;

    public ChestStealer() {
        super("Chest Stealer", "Automatically loots chests.", ModuleCategory.PLAYER);
        this.delay.visibleWhen(() -> this.mode.is("Default"));
        this.defaultWhitelist.visibleWhen(() -> (Boolean)this.whitelistEnabled.getValue() != false && this.mode.is("Default"));
        this.ftWardenWhitelist.visibleWhen(() -> (Boolean)this.whitelistEnabled.getValue() != false && this.mode.is("FT Warden"));
        this.fillItemNames();
    }

    @Override
    protected void onEnable() {
        this.resetState();
    }

    @Override
    protected void onDisable() {
        this.resetState();
    }

    @SubscribeEvent
    private void onTick(TickEvent.Post event) {
        class_310 client = event.getClient();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            this.resetState();
            return;
        }
        class_1703 class_17032 = client.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            this.resetState();
            return;
        }
        class_1707 menu = (class_1707)class_17032;
        if (this.mode.is("FT Warden")) {
            if (!this.chestSessionActive) {
                this.chestSessionActive = true;
                this.stopTicksRemaining = 2;
                this.lootWatch.reset();
            }
            client.field_1724.method_5728(false);
            if (this.stopTicksRemaining > 0) {
                --this.stopTicksRemaining;
                return;
            }
            this.stealAllFromChest(menu);
            return;
        }
        this.chestSessionActive = false;
        this.stopTicksRemaining = 0;
        if ((Double)this.delay.getValue() <= 0.0) {
            this.stealAllFromChest(menu);
        } else if (this.lootWatch.every((Double)this.delay.getValue())) {
            this.quickMoveNextSlot(menu);
        }
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        class_310 client = class_310.method_1551();
        if (this.mode.is("FT Warden") && this.chestSessionActive && client.field_1724 != null && client.field_1724.field_7512 instanceof class_1707) {
            event.inputNone();
            client.field_1724.method_5728(false);
        }
    }

    private void quickMoveNextSlot(class_1707 menu) {
        int chestSlots = menu.method_17388() * 9;
        for (int slotIndex = 0; slotIndex < chestSlots; ++slotIndex) {
            class_1735 slot = (class_1735)menu.field_7761.get(slotIndex);
            if (!slot.method_7681() || !this.shouldLoot(slot.method_7677())) continue;
            InventoryTask.clickSlot(slotIndex, 0, class_1713.field_7794, true);
            break;
        }
        this.closeIfChestEmpty(menu);
    }

    private void stealAllFromChest(class_1707 menu) {
        int chestSlots = menu.method_17388() * 9;
        for (int slotIndex = 0; slotIndex < chestSlots; ++slotIndex) {
            class_1735 slot = (class_1735)menu.field_7761.get(slotIndex);
            if (!slot.method_7681() || !this.shouldLoot(slot.method_7677())) continue;
            InventoryTask.clickSlot(slotIndex, 0, class_1713.field_7794, true);
        }
        this.closeIfChestEmpty(menu);
    }

    private void closeIfChestEmpty(class_1707 menu) {
        int chestSlots = menu.method_17388() * 9;
        for (int slotIndex = 0; slotIndex < chestSlots; ++slotIndex) {
            class_1735 slot = (class_1735)menu.field_7761.get(slotIndex);
            if (!slot.method_7681() || !this.shouldLoot(slot.method_7677())) continue;
            return;
        }
        InventoryTask.closeScreen(false);
    }

    private boolean shouldLoot(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }
        if (!((Boolean)this.whitelistEnabled.getValue()).booleanValue()) {
            return true;
        }
        Set selected = (Set)this.getActiveWhitelist().getValue();
        if (selected == null || selected.isEmpty()) {
            return true;
        }
        String itemName = this.resolveWhitelistName(stack);
        return itemName != null && selected.contains(itemName);
    }

    private MultiModeSetting getActiveWhitelist() {
        return this.mode.is("FT Warden") ? this.ftWardenWhitelist : this.defaultWhitelist;
    }

    private String resolveWhitelistName(class_1799 stack) {
        class_1747 blockItem;
        class_1792 item = stack.method_7909();
        String mapped = this.itemNames.get(item);
        if (mapped != null) {
            return mapped;
        }
        if (item instanceof class_1747 && (blockItem = (class_1747)item).method_7711() instanceof class_2480) {
            return "Shulker Box";
        }
        return null;
    }

    private void fillItemNames() {
        this.itemNames.put(class_1802.field_8288, "Totem");
        this.itemNames.put(class_1802.field_22027, "Netherite Helmet");
        this.itemNames.put(class_1802.field_22028, "Netherite Chestplate");
        this.itemNames.put(class_1802.field_22029, "Netherite Leggings");
        this.itemNames.put(class_1802.field_22030, "Netherite Boots");
        this.itemNames.put(class_1802.field_22022, "Netherite Sword");
        this.itemNames.put(class_1802.field_22024, "Netherite Pickaxe");
        this.itemNames.put(class_1802.field_8367, "Enchanted Golden Apple");
        this.itemNames.put(class_1802.field_8575, "Player Head");
        this.itemNames.put(class_1802.field_22020, "Netherite Ingot");
        this.itemNames.put(class_1802.field_8712, "Dragon Head");
        this.itemNames.put(class_1802.field_8833, "Elytra");
        this.itemNames.put(class_1802.field_8543, "Snowball");
        this.itemNames.put(class_1802.field_8436, "Splash Potion");
        this.itemNames.put(class_1802.field_8366, "Tripwire Hook");
        this.itemNames.put(class_1802.field_22021, "Netherite Scrap");
        this.itemNames.put(class_1802.field_8668, "Beacon");
        this.itemNames.put(class_1802.field_8086, "Villager Spawn Egg");
    }

    private void resetState() {
        this.lootWatch.reset();
        this.chestSessionActive = false;
        this.stopTicksRemaining = 0;
    }
}

