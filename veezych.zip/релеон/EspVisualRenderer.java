/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1291
 *  net.minecraft.class_1293
 *  net.minecraft.class_1304
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_3532
 *  net.minecraft.class_742
 */
package releon.ru.api.module.impl.visual.esp;

import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_742;
import releon.ru.api.module.impl.visual.esp.EspGeometry;
import releon.ru.api.module.impl.visual.esp.EspHealthTracker;
import releon.ru.api.module.impl.visual.esp.TagPart;
import releon.ru.utils.render.Render3D;
import releon.ru.utils.render.color.ColorUtil;
import releon.ru.utils.render.item.RenderItem;
import releon.ru.utils.render.item.RenderItemOptions;
import releon.ru.utils.render.ui.Render2D;
import releon.ru.utils.render.ui.font.FontType;

public final class EspVisualRenderer {
    private EspVisualRenderer() {
    }

    public static void draw2DBox(EspGeometry.ScreenBox box, int color, float alpha) {
        float x = EspVisualRenderer.roundHalf((float)box.minX());
        float y = EspVisualRenderer.roundHalf((float)box.minY());
        float width = Math.max(2.0f, EspVisualRenderer.roundHalf((float)box.width()));
        float height = Math.max(2.0f, EspVisualRenderer.roundHalf((float)box.height()));
        float length = Math.max(5.0f, Math.min(Math.min(width * 0.34f, height * 0.22f), 18.0f));
        EspVisualRenderer.drawCornerSegments(x, y, width, height, length, 3.1f, ColorUtil.rgba(0, 0, 0, Math.round(155.0f * alpha)));
        EspVisualRenderer.drawCornerSegments(x, y, width, height, length, 1.35f, ColorUtil.multAlpha(color, alpha));
    }

    public static void draw3DCornerBox(class_238 box, int color, float width) {
        double lenX = Math.max(0.08, Math.min(box.method_17939() * 0.38, 0.34));
        double lenY = Math.max(0.18, Math.min(box.method_17940() * 0.22, 0.48));
        double lenZ = Math.max(0.08, Math.min(box.method_17941() * 0.38, 0.34));
        int renderColor = ColorUtil.multAlpha(color, 0.92f);
        for (int xi = 0; xi < 2; ++xi) {
            for (int yi = 0; yi < 2; ++yi) {
                for (int zi = 0; zi < 2; ++zi) {
                    double x = xi == 0 ? box.field_1323 : box.field_1320;
                    double y = yi == 0 ? box.field_1322 : box.field_1325;
                    double z = zi == 0 ? box.field_1321 : box.field_1324;
                    double dx = xi == 0 ? lenX : -lenX;
                    double dy = yi == 0 ? lenY : -lenY;
                    double dz = zi == 0 ? lenZ : -lenZ;
                    class_243 corner = new class_243(x, y, z);
                    Render3D.drawLineOverlay(corner, new class_243(x + dx, y, z), renderColor, width);
                    Render3D.drawLineOverlay(corner, new class_243(x, y + dy, z), renderColor, width);
                    Render3D.drawLineOverlay(corner, new class_243(x, y, z + dz), renderColor, width);
                }
            }
        }
    }

    public static float resolve3DLineWidth(class_310 mc, class_238 box) {
        double distance = mc.field_1773.method_19418().method_71156().method_1022(box.method_1005());
        return (float)class_3532.method_15350((double)(2.4 - distance * 0.012), (double)1.05, (double)2.4);
    }

    public static void drawTagFrame(class_1657 player, List<TagPart> parts, class_1799 iconStack, boolean roundIcon, EspGeometry.ScreenBox box, EspGeometry.ScreenAnchor anchor, float alpha, class_332 graphics) {
        boolean playerTag = player != null;
        float textSize = 6.0f;
        float textWidth = 0.0f;
        for (TagPart part : parts) {
            textWidth += Render2D.textWidth(part.font(), part.text(), textSize);
        }
        boolean hasIcon = !iconStack.method_7960();
        boolean hasHead = playerTag;
        float headSize = hasHead ? 8.0f : 0.0f;
        float headGap = hasHead && !parts.isEmpty() ? 3.2f : 0.0f;
        float iconSize = hasIcon ? 9.0f : 0.0f;
        float iconBgSize = hasIcon ? iconSize + 3.0f : 0.0f;
        float iconGap = hasIcon && !parts.isEmpty() ? 2.8f : 0.0f;
        float paddingX = 3.2f;
        float paddingY = 1.8f;
        float height = Math.max(textSize + paddingY * 2.0f + 1.0f, Math.max(hasIcon ? iconBgSize + 2.0f : 0.0f, hasHead ? headSize + 2.0f : 0.0f));
        float totalWidth = textWidth + headSize + headGap + iconBgSize + iconGap;
        double anchorX = anchor != null ? anchor.x() : box.centerX();
        double anchorY = anchor != null ? anchor.y() : box.minY();
        float x = (float)(anchorX - (double)(totalWidth * 0.5f));
        float y = (float)anchorY - height - 1.0f + 0.0f;
        float backgroundX = x - (hasIcon && parts.isEmpty() ? 0.0f : paddingX);
        float backgroundWidth = totalWidth + (hasIcon && parts.isEmpty() ? 0.0f : paddingX * 2.0f);
        Render2D.rect(backgroundX, y - 1.0f, backgroundWidth, height + 2.0f, 3.0f, ColorUtil.rgba(0, 0, 0, Math.round(185.0f * alpha)));
        float drawX = x;
        if (hasHead) {
            EspVisualRenderer.drawPlayerHead(graphics, player, drawX, y + (height - headSize) * 0.5f + 0.0f, headSize, alpha);
            drawX += headSize + headGap;
        }
        if (hasIcon) {
            float iconBgX = drawX;
            float iconBgY = y + (height - iconBgSize) * 0.5f + 0.0f;
            if (roundIcon) {
                Render2D.rect(iconBgX, iconBgY, iconBgSize, iconBgSize, iconBgSize * 0.5f, ColorUtil.rgba(22, 22, 22, Math.round(170.0f * alpha)));
            }
            RenderItem.item(iconStack, iconBgX + 1.5f, iconBgY + 1.5f, iconSize, RenderItemOptions.noDecorations(alpha));
            drawX += iconBgSize + iconGap;
        }
        float textY = y + (height - textSize) * 0.5f - 0.75f;
        for (TagPart part : parts) {
            Render2D.text(part.font(), part.text(), drawX, textY + 0.0f + part.yOffset(), textSize, ColorUtil.multAlpha(part.color(), alpha));
            drawX += Render2D.textWidth(part.font(), part.text(), textSize);
        }
    }

    public static void drawCompactItemTag(List<ItemTagRow> rows, double anchorX, double anchorY, float alpha, class_332 graphics) {
        if (rows == null || rows.isEmpty()) {
            return;
        }
        float textSize = 6.2f;
        float rowHeight = 11.0f;
        float iconSize = 8.5f;
        float iconGap = 3.0f;
        float paddingX = 4.2f;
        float paddingY = 3.0f;
        float countGap = 4.0f;
        float nameWidth = 0.0f;
        float countWidth = 0.0f;
        for (ItemTagRow row : rows) {
            nameWidth = Math.max(nameWidth, Render2D.textWidth(FontType.SEMIBOLD, row.name(), textSize));
            countWidth = Math.max(countWidth, Render2D.textWidth(FontType.SEMIBOLD, EspVisualRenderer.compactCount(row.count()), textSize));
        }
        float width = paddingX * 2.0f + iconSize + iconGap + nameWidth + countGap + countWidth;
        float height = paddingY * 2.0f + (float)rows.size() * rowHeight;
        float x = (float)anchorX - width * 0.5f;
        float y = (float)anchorY - height - 2.0f + 0.0f;
        Render2D.rect(x, y, width, height, 3.0f, ColorUtil.rgba(0, 0, 0, Math.round(185.0f * alpha)));
        RenderItemOptions itemOptions = RenderItemOptions.noDecorations(alpha);
        float rowY = y + paddingY;
        for (ItemTagRow row : rows) {
            float iconY = rowY + (rowHeight - iconSize) * 0.5f;
            RenderItem.item(row.stack(), x + paddingX, iconY, iconSize, itemOptions);
            float textY = rowY + (rowHeight - textSize) * 0.5f - 0.65f;
            float textX = x + paddingX + iconSize + iconGap;
            Render2D.text(FontType.SEMIBOLD, row.name(), textX, textY, textSize, ColorUtil.rgba(245, 245, 245, Math.round(255.0f * alpha)));
            String count = EspVisualRenderer.compactCount(row.count());
            float rowCountWidth = Render2D.textWidth(FontType.SEMIBOLD, count, textSize);
            Render2D.text(FontType.SEMIBOLD, count, x + width - paddingX - rowCountWidth, textY, textSize, ColorUtil.rgba(165, 165, 165, Math.round(245.0f * alpha)));
            rowY += rowHeight;
        }
    }

    public static void drawHealthBar(EspGeometry.ScreenBox box, class_1309 entity, float alpha, EspHealthTracker healthTracker) {
        float health = healthTracker.resolveDisplayHealth(entity);
        float maxHealth = Math.max(1.0f, entity.method_6063() + entity.method_6067());
        maxHealth = Math.max(maxHealth, health);
        float progress = Math.clamp(health / maxHealth, 0.0f, 1.0f);
        float x = (float)box.minX() - 4.6f;
        float y = (float)box.minY();
        float height = (float)box.height();
        float fillHeight = Math.max(1.0f, height * progress);
        int healthColor = ColorUtil.lerpColor(ColorUtil.rgba(255, 70, 70, 240), ColorUtil.rgba(80, 255, 120, 240), progress);
        Render2D.rect(x, y, 2.1f, height, 1.0f, ColorUtil.rgba(0, 0, 0, Math.round(135.0f * alpha)));
        Render2D.rect(x, y + height - fillHeight, 2.1f, fillHeight, 1.0f, ColorUtil.multAlpha(healthColor, alpha));
    }

    public static int healthTextColor(class_1309 entity, EspHealthTracker healthTracker) {
        float health = healthTracker.resolveDisplayHealth(entity);
        float maxHealth = Math.max(1.0f, entity.method_6063() + entity.method_6067());
        maxHealth = Math.max(maxHealth, health);
        return ColorUtil.lerpColor(ColorUtil.rgba(255, 70, 70, 255), ColorUtil.rgba(70, 255, 115, 255), Math.clamp(health / maxHealth, 0.0f, 1.0f));
    }

    public static void drawEquipment(class_1657 player, EspGeometry.ScreenBox box, EspGeometry.ScreenAnchor anchor, float alpha) {
        class_1799 mainHand;
        class_1799 boots;
        class_1799 leggings;
        class_1799 chestplate;
        class_1799 helmet;
        class_1799 offhand = player.method_6079();
        int itemCount = EspVisualRenderer.equipmentCount(offhand, helmet = player.method_6118(class_1304.field_6169), chestplate = player.method_6118(class_1304.field_6174), leggings = player.method_6118(class_1304.field_6172), boots = player.method_6118(class_1304.field_6166), mainHand = player.method_6047());
        if (itemCount == 0) {
            return;
        }
        float totalWidth = (float)itemCount * 10.0f + (float)(itemCount - 1) * 1.4f;
        double anchorX = anchor != null ? anchor.x() : box.centerX();
        double anchorY = anchor != null ? anchor.y() : box.minY();
        float x = (float)(anchorX - (double)(totalWidth * 0.5f));
        float y = (float)anchorY - 27.0f;
        RenderItemOptions options = RenderItemOptions.decorated(alpha);
        x = EspVisualRenderer.drawEquipmentItem(offhand, x, y, options);
        x = EspVisualRenderer.drawEquipmentItem(helmet, x, y, options);
        x = EspVisualRenderer.drawEquipmentItem(chestplate, x, y, options);
        x = EspVisualRenderer.drawEquipmentItem(leggings, x, y, options);
        x = EspVisualRenderer.drawEquipmentItem(boots, x, y, options);
        EspVisualRenderer.drawEquipmentItem(mainHand, x, y, options);
    }

    public static void drawPotions(class_1309 entity, EspGeometry.ScreenBox box, float alpha) {
        if (entity.method_6026().isEmpty()) {
            return;
        }
        float x = (float)box.maxX() + 4.0f;
        float y = (float)box.minY() + 1.0f;
        int shown = 0;
        for (class_1293 effect : entity.method_6026()) {
            if (shown >= 5) break;
            Render2D.effectIcon(effect, x, y - 0.4f, 7.0f, ColorUtil.rgba(255, 255, 255, Math.round(235.0f * alpha)));
            Render2D.text(FontType.SEMIBOLD, EspVisualRenderer.effectText(effect), x + 8.2f, y + 0.1f, 5.8f, ColorUtil.rgba(235, 235, 235, Math.round(230.0f * alpha)));
            y += 8.5f;
            ++shown;
        }
    }

    private static void drawPlayerHead(class_332 graphics, class_1657 player, float x, float y, float size, float alpha) {
        class_742 clientPlayer;
        block3: {
            block2: {
                if (graphics == null || !(player instanceof class_742)) break block2;
                clientPlayer = (class_742)player;
                if (!(size <= 0.0f) && !(alpha <= 0.0f)) break block3;
            }
            return;
        }
        class_2960 skinTexture = clientPlayer.method_52814().comp_1626().comp_3627();
        String texture = skinTexture.toString();
        int color = ColorUtil.rgba(255, 255, 255, Math.round(255.0f * Math.clamp(alpha, 0.0f, 1.0f)));
        Render2D.imageUvNearest(texture, x, y, size, size, 2.0f, 1.0f, 0.125f, 0.125f, 0.25f, 0.25f, color);
        Render2D.imageUvNearest(texture, x, y, size, size, 2.0f, 1.0f, 0.625f, 0.125f, 0.75f, 0.25f, color);
    }

    private static String compactCount(int count) {
        return count > 1 ? "x" + count : "x1";
    }

    private static String effectText(class_1293 effect) {
        String name = ((class_1291)effect.method_5579().comp_349()).method_5560().getString();
        int level = effect.method_5578() + 1;
        return name + (String)(level > 1 ? " " + level : "") + " " + EspVisualRenderer.formatDuration(effect.method_5584());
    }

    private static String formatDuration(int ticks) {
        if (ticks < 0 || ticks >= 72000) {
            return "**:**";
        }
        int seconds = Math.max(0, ticks / 20);
        return seconds / 60 + ":" + (seconds % 60 < 10 ? "0" : "") + seconds % 60;
    }

    private static int equipmentCount(class_1799 offhand, class_1799 helmet, class_1799 chestplate, class_1799 leggings, class_1799 boots, class_1799 mainHand) {
        int count = 0;
        if (!offhand.method_7960()) {
            ++count;
        }
        if (!helmet.method_7960()) {
            ++count;
        }
        if (!chestplate.method_7960()) {
            ++count;
        }
        if (!leggings.method_7960()) {
            ++count;
        }
        if (!boots.method_7960()) {
            ++count;
        }
        if (!mainHand.method_7960()) {
            ++count;
        }
        return count;
    }

    private static float drawEquipmentItem(class_1799 stack, float x, float y, RenderItemOptions options) {
        if (!stack.method_7960()) {
            RenderItem.item(stack, x, y, 8.0f, options);
            return x + 11.4f;
        }
        return x;
    }

    private static void drawCornerSegments(float x, float y, float width, float height, float length, float thickness, int color) {
        float right = x + width;
        float bottom = y + height;
        float half = thickness * 0.5f;
        Render2D.rect(x - half, y - half, length, thickness, 0.0f, color);
        Render2D.rect(x - half, y - half, thickness, length, 0.0f, color);
        Render2D.rect(right - length + half, y - half, length, thickness, 0.0f, color);
        Render2D.rect(right - half, y - half, thickness, length, 0.0f, color);
        Render2D.rect(x - half, bottom - half, length, thickness, 0.0f, color);
        Render2D.rect(x - half, bottom - length + half, thickness, length, 0.0f, color);
        Render2D.rect(right - length + half, bottom - half, length, thickness, 0.0f, color);
        Render2D.rect(right - half, bottom - length + half, thickness, length, 0.0f, color);
    }

    private static float roundHalf(float value) {
        return (float)Math.round(value * 2.0f) / 2.0f;
    }

    public record ItemTagRow(class_1799 stack, String name, int count) {
    }
}

