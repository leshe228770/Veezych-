/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  org.joml.Matrix3x2f
 *  org.joml.Matrix3x2fStack
 *  org.joml.Matrix3x2fc
 */
package releon.ru.utils.render.ui;

import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;

public final class Render2DCoordinateSpace {
    private static final float DESIGN_GUI_SCALE = 2.0f;
    private static final ThreadLocal<PoseCache> POSE_CACHE = ThreadLocal.withInitial(PoseCache::new);

    private Render2DCoordinateSpace() {
    }

    public static Matrix3x2f pose(class_332 graphics) {
        Matrix3x2fStack source = graphics.method_51448();
        float scale = Render2DCoordinateSpace.guiIndependentScale();
        PoseCache cache = POSE_CACHE.get();
        if (cache.matches(graphics, (Matrix3x2f)source, scale)) {
            return cache.pose;
        }
        Matrix3x2f pose = new Matrix3x2f((Matrix3x2fc)source);
        if (scale != 1.0f) {
            pose.scale(scale);
        }
        cache.set(graphics, (Matrix3x2f)source, scale, pose);
        return pose;
    }

    public static void applyGuiScaleIndependence(Matrix3x2f pose) {
        float scale = Render2DCoordinateSpace.guiIndependentScale();
        if (scale != 1.0f) {
            pose.scale(scale);
        }
    }

    public static float toGui(float value) {
        return value * Render2DCoordinateSpace.guiIndependentScale();
    }

    public static int toGuiInt(float value) {
        return Math.round(Render2DCoordinateSpace.toGui(value));
    }

    public static float guiIndependentScale() {
        return 2.0f / (float)Render2DCoordinateSpace.guiScale();
    }

    public static float designGuiScale() {
        return 2.0f;
    }

    public static int guiScale() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null) {
            return 1;
        }
        class_1041 window = minecraft.method_22683();
        if (window == null) {
            return 1;
        }
        return Math.max(1, window.method_4495());
    }

    private static final class PoseCache {
        private class_332 graphics;
        private Matrix3x2f pose;
        private float scale;
        private float m00;
        private float m01;
        private float m10;
        private float m11;
        private float m20;
        private float m21;

        private PoseCache() {
        }

        private boolean matches(class_332 graphics, Matrix3x2f source, float scale) {
            return this.graphics == graphics && this.pose != null && this.scale == scale && this.m00 == source.m00() && this.m01 == source.m01() && this.m10 == source.m10() && this.m11 == source.m11() && this.m20 == source.m20() && this.m21 == source.m21();
        }

        private void set(class_332 graphics, Matrix3x2f source, float scale, Matrix3x2f pose) {
            this.graphics = graphics;
            this.pose = pose;
            this.scale = scale;
            this.m00 = source.m00();
            this.m01 = source.m01();
            this.m10 = source.m10();
            this.m11 = source.m11();
            this.m20 = source.m20();
            this.m21 = source.m21();
        }
    }
}

