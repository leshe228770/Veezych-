/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_4597$class_4598
 */
package releon.ru.api.module.impl.visual;

import java.awt.Color;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.WorldRenderEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;
import releon.ru.api.module.impl.combat.AuraModule;
import releon.ru.api.settings.impl.ColorSetting;
import releon.ru.api.settings.impl.ModeSetting;
import releon.ru.utils.render.animation.Easings;
import releon.ru.utils.render.animation.SmoothAnimation;
import releon.ru.utils.render.world.targetesp.ChainTargetEspRenderer;
import releon.ru.utils.render.world.targetesp.GhostTargetEspRenderer;
import releon.ru.utils.render.world.targetesp.MarkerTargetEspRenderer;
import releon.ru.utils.render.world.targetesp.RhombTargetEspRenderer;
import releon.ru.utils.render.world.targetesp.SkullTargetEspRenderer;
import releon.ru.utils.render.world.targetesp.TargetEspMath;
import releon.ru.utils.render.world.targetesp.TargetEspRenderContext;

public class TargetESP
extends Module {
    private static TargetESP instance;
    private final SmoothAnimation alphaAnimation = new SmoothAnimation();
    private final ModeSetting mode = this.register(new ModeSetting("Mode", "Target highlight type.", "Ghost", "Rhomb", "Rhomb 2", "Ghost", "Chain", "Skull"));
    private final ColorSetting color1 = this.register(new ColorSetting("Color 1", "Primary target ESP color.", new Color(127, 242, 255, 136)));
    private final ColorSetting color2 = this.register(new ColorSetting("Color 2", "Secondary target ESP color.", new Color(255, 50, 150, 255)));
    private class_243 smoothedPos;
    private class_1309 lastTarget;
    private float hurtProgress;
    private float chainImpactProgress;
    private long lastFrameTime = System.currentTimeMillis();

    public TargetESP() {
        super("Target ESP", "Highlights the current Aura target.", ModuleCategory.VISUAL);
        instance = this;
        this.alphaAnimation.set(0.0);
    }

    public static TargetESP getInstance() {
        return instance;
    }

    @Override
    protected void onDisable() {
        this.alphaAnimation.set(0.0);
        this.smoothedPos = null;
        this.lastTarget = null;
        this.hurtProgress = 0.0f;
        this.chainImpactProgress = 0.0f;
    }

    @SubscribeEvent
    private void onRender3D(WorldRenderEvent event) {
        class_1309 target;
        long frameTime = System.currentTimeMillis();
        float deltaTime = Math.max(1.0f, Math.min((float)(frameTime - this.lastFrameTime), 100.0f)) / 16.666666f;
        this.lastFrameTime = frameTime;
        class_1309 class_13092 = target = AuraModule.getInstance() != null && AuraModule.getInstance().isEnabled() ? AuraModule.target : null;
        if (target == null || !target.method_5805()) {
            this.alphaAnimation.run(0.0, 0.25, Easings.CUBIC_OUT, true);
        } else {
            if (this.lastTarget != target || this.smoothedPos == null) {
                this.lastTarget = target;
                this.smoothedPos = target.method_30950(event.getPartialTicks());
            } else {
                this.smoothToTarget(target, event.getPartialTicks());
            }
            this.alphaAnimation.run(1.0, 0.25, Easings.CUBIC_OUT, true);
        }
        this.alphaAnimation.update();
        float alpha = class_3532.method_15363((float)this.alphaAnimation.get(), (float)0.0f, (float)1.0f);
        if (alpha <= 0.01f || this.lastTarget == null || this.smoothedPos == null) {
            return;
        }
        this.hurtProgress = this.lastTarget.field_6235 > 0 ? (float)this.lastTarget.field_6235 / 10.0f : Math.max(0.0f, this.hurtProgress - 0.1f * deltaTime);
        float impactTarget = this.lastTarget.field_6235 > 0 ? 1.0f : 0.0f;
        float impactStep = (impactTarget > this.chainImpactProgress ? 0.3f : 0.1f) * deltaTime;
        this.chainImpactProgress = TargetEspMath.approach(this.chainImpactProgress, impactTarget, impactStep);
        class_243 cameraPos = TargetESP.mc.field_1773.method_19418().method_71156();
        float cameraFade = this.computeCameraFade(this.lastTarget, cameraPos, this.smoothedPos);
        float renderAlpha = alpha * cameraFade;
        if (renderAlpha <= 0.01f) {
            return;
        }
        class_4587 stack = event.getStack();
        class_4597.class_4598 provider = mc.method_22940().method_23000();
        stack.method_22903();
        stack.method_22904(this.smoothedPos.field_1352 - cameraPos.field_1352, this.smoothedPos.field_1351 - cameraPos.field_1351, this.smoothedPos.field_1350 - cameraPos.field_1350);
        TargetEspRenderContext context = new TargetEspRenderContext(this.lastTarget, renderAlpha, event.getPartialTicks(), frameTime, ((Color)this.color1.getValue()).getRGB(), ((Color)this.color2.getValue()).getRGB(), this.hurtProgress, this.chainImpactProgress);
        if (this.mode.is("Rhomb")) {
            RhombTargetEspRenderer.render(stack, provider, context);
            RhombTargetEspRenderer.endBatch(provider);
        } else if (this.mode.is("Rhomb 2")) {
            MarkerTargetEspRenderer.render(stack, provider, context);
            MarkerTargetEspRenderer.endBatch(provider);
        } else if (this.mode.is("Ghost")) {
            GhostTargetEspRenderer.render(stack, provider, context);
            GhostTargetEspRenderer.endBatch(provider);
        } else if (this.mode.is("Chain")) {
            ChainTargetEspRenderer.render(stack, provider, context);
            ChainTargetEspRenderer.endBatch(provider);
        } else if (this.mode.is("Skull")) {
            SkullTargetEspRenderer.render(stack, provider, context);
            SkullTargetEspRenderer.endBatch(provider);
        }
        stack.method_22909();
    }

    private void smoothToTarget(class_1309 target, float partialTicks) {
        class_243 targetPos = target.method_30950(partialTicks);
        float smoothing = Math.min(1.0f, Math.max(0.12f, partialTicks * 1.5f));
        this.smoothedPos = new class_243(this.smoothedPos.field_1352 + (targetPos.field_1352 - this.smoothedPos.field_1352) * (double)smoothing, this.smoothedPos.field_1351 + (targetPos.field_1351 - this.smoothedPos.field_1351) * (double)smoothing, this.smoothedPos.field_1350 + (targetPos.field_1350 - this.smoothedPos.field_1350) * (double)smoothing);
    }

    private float computeCameraFade(class_1309 target, class_243 cameraPos, class_243 targetPos) {
        class_238 dangerZone = target.method_5829().method_1014(0.35);
        if (dangerZone.method_1006(cameraPos)) {
            return 0.0f;
        }
        double distance = cameraPos.method_1022(targetPos);
        float fadeStart = Math.max(1.25f, target.method_17681() * 1.6f);
        float fadeEnd = fadeStart + 0.9f;
        return class_3532.method_15363((float)((float)((distance - (double)fadeStart) / (double)(fadeEnd - fadeStart))), (float)0.0f, (float)1.0f);
    }
}

