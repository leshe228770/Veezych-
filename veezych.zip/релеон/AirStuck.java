/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2828
 *  net.minecraft.class_310
 */
package releon.ru.api.module.impl.movement;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import releon.ru.api.events.annotation.SubscribeEvent;
import releon.ru.api.events.impl.InputEvent;
import releon.ru.api.events.impl.PacketEvent;
import releon.ru.api.events.impl.PlayerTravelEvent;
import releon.ru.api.events.impl.TickEvent;
import releon.ru.api.module.Module;
import releon.ru.api.module.ModuleCategory;

public class AirStuck
extends Module {
    private static final double RELEASE_FALL_VELOCITY = -0.0784;
    private class_243 stuckPosition;

    public AirStuck() {
        super("AirStuck", "Air Stuck", ModuleCategory.MOVEMENT);
    }

    @Override
    protected void onEnable() {
        this.capturePosition();
        this.freezePlayer();
    }

    @Override
    protected void onDisable() {
        this.releasePlayer();
        this.stuckPosition = null;
    }

    @Override
    public void onTick(class_310 client) {
        this.freezePlayer();
    }

    @SubscribeEvent
    private void onPreTick(TickEvent.Pre event) {
        this.freezePlayer();
    }

    @SubscribeEvent
    private void onInput(InputEvent event) {
        event.inputNone();
    }

    @SubscribeEvent
    private void onTravel(PlayerTravelEvent event) {
        if (!event.isPre()) {
            return;
        }
        this.freezePlayer();
        event.setMotion(class_243.field_1353);
        event.setCancelled(true);
    }

    @SubscribeEvent
    private void onPacket(PacketEvent event) {
        if (event.isSend() && event.getPacket() instanceof class_2828) {
            event.setCancelled(true);
        }
    }

    private void freezePlayer() {
        if (AirStuck.mc.field_1724 == null || AirStuck.mc.field_1687 == null) {
            this.stuckPosition = null;
            return;
        }
        if (this.stuckPosition == null) {
            this.capturePosition();
        }
        AirStuck.mc.field_1724.method_18799(class_243.field_1353);
        AirStuck.mc.field_1724.method_5814(this.stuckPosition.field_1352, this.stuckPosition.field_1351, this.stuckPosition.field_1350);
        AirStuck.mc.field_1724.method_5728(false);
        AirStuck.mc.field_1724.field_6017 = 0.0;
    }

    private void capturePosition() {
        if (AirStuck.mc.field_1724 != null) {
            this.stuckPosition = AirStuck.mc.field_1724.method_73189();
        }
    }

    private void releasePlayer() {
        if (AirStuck.mc.field_1724 == null || AirStuck.mc.field_1687 == null) {
            return;
        }
        double fallVelocity = Math.min(AirStuck.mc.field_1724.method_18798().field_1351, -0.0784);
        double releaseMoveY = this.getReleaseMoveY(fallVelocity);
        if (releaseMoveY != 0.0) {
            AirStuck.mc.field_1724.method_5814(AirStuck.mc.field_1724.method_23317(), AirStuck.mc.field_1724.method_23318() + releaseMoveY, AirStuck.mc.field_1724.method_23321());
        }
        AirStuck.mc.field_1724.method_18800(0.0, fallVelocity, 0.0);
        AirStuck.mc.field_1724.method_5728(false);
    }

    private double getReleaseMoveY(double moveY) {
        class_238 movedBox = AirStuck.mc.field_1724.method_5829().method_989(0.0, moveY, 0.0);
        return AirStuck.mc.field_1687.method_8587((class_1297)AirStuck.mc.field_1724, movedBox) ? moveY : 0.0;
    }
}

